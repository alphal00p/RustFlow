from pathlib import Path
import hashlib,json,os,shlex,subprocess
root=Path.cwd();out=root/'target/automatic-scalar-comparison-final';out.mkdir(exist_ok=True)
main=Path('/common/dev/amflow/target')
# The parent froze this exact library after its full dependency-update gate.
baseline=main/'symbolica-community-release-fa5fe1b/libsymbolica_amflow-c31211c1e00f5a5b.rlib'
baseline_features=json.loads((main/'release/.fingerprint/symbolica-amflow-c31211c1e00f5a5b/lib-symbolica_amflow.json').read_text())['features']
def matching_features(p):
 name=p.stem.removeprefix('lib').replace('symbolica_amflow-','symbolica-amflow-',1)
 metadata=root/'target/release/.fingerprint'/name/'lib-symbolica_amflow.json'
 return metadata.exists() and json.loads(metadata.read_text())['features']==baseline_features
candidate=max(filter(matching_features,(root/'target/release/deps').glob('libsymbolica_amflow-*.rlib')),key=lambda p:p.stat().st_mtime_ns)
compile_env=dict(os.environ,CARGO_CRATE_NAME='automatic_scalar_oracle')
source=root/'target/automatic_scalar_comparison.rs'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
records={}
for mode,library,dep_target in [('baseline',baseline,main),('automatic',candidate,root/'target')]:
 native=set()
 for p in (dep_target/'release/build').glob('*/output'):
  for line in p.read_text(errors='replace').splitlines():
   for prefix in ['cargo:rustc-link-search=','cargo::rustc-link-search=']:
    if line.startswith(prefix):native.add(line[len(prefix):])
 binary=out/mode
 args=['rustc','--edition=2024','--crate-name','automatic_scalar_oracle','-C','opt-level=3','-C','debuginfo=1',str(source),'--extern',f'symbolica_amflow={library}','-L',f'dependency={dep_target}/release/deps','-o',str(binary)]
 for location in sorted(native):args+=['-L',location]
 args+=shlex.split(os.environ.get('RUSTFLAGS',''))
 with (out/f'{mode}-build.log').open('w') as f:subprocess.run(args,check=True,env=compile_env,stdout=f,stderr=subprocess.STDOUT)
 result=out/f'{mode}.txt'
 with (out/f'{mode}-run.log').open('w') as f:subprocess.run([str(binary),str(result)],check=True,stdout=f,stderr=subprocess.STDOUT)
 records[mode]={'library':str(library),'library_sha256':sha(library),'binary_sha256':sha(binary),'output_sha256':sha(result),'lines':len(result.read_text().splitlines())}
assert (out/'baseline.txt').read_bytes()==(out/'automatic.txt').read_bytes(),'exact scalar preservation comparison differs'
assert records['baseline']['library_sha256']!=records['automatic']['library_sha256'],'candidate must contain changed implementation'
report={'features':baseline_features,'compiler':subprocess.check_output(['rustc','--version'],text=True).strip(),'cases':4,'exact_output_match':True,'harness_sha256':sha(source),'runs':records}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
