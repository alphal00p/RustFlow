use std::collections::BTreeMap;
use std::fmt::Write;
use symbolica_amflow::symbolica::prelude::*;
use symbolica_amflow::{kinematics::KinematicSystem, physical_transport::PhysicalTransport, transport_cache::*, *};

fn main() -> Result<()> {
    let p=Precision::decimal(90)?;
    let x=symbol!("automatic_scalar_oracle::x");
    let eps=symbol!("automatic_scalar_oracle::eps");
    let mut output=String::new();
    for case in 0..4 {
        let (matrix,values,end)=match case {
            0=>(vec![vec![Atom::one()]],vec![vec![p.i(1)]],Atom::one()),
            1=>(vec![vec![Atom::one()/(Atom::var(x)+1)]],vec![vec![p.i(1)]],Atom::num(8)),
            2=>(vec![vec![Atom::one(),Atom::one()],vec![Atom::new(),Atom::num(-1)]],vec![vec![p.i(1),p.i(1)]],Atom::one()),
            _=>(vec![vec![Atom::var(eps)/(Atom::var(x)+1)]],vec![vec![p.i(1)],vec![p.zero()],vec![p.zero()]],Atom::num(8)),
        };
        let n=matrix.len();
        let count=values.len();
        let engine=PhysicalTransport::new(KinematicSystem {epsilon:eps, derivatives:BTreeMap::from([(x,matrix)])},&(0..n).map(|i|symbol!("automatic_scalar_oracle::I").call(i as i64)).collect::<Vec<_>>(),&Atom::one(),Prescription::PlusI0,"regular scalar preservation oracle")?;
        let mut cache=BoundaryCache::default();
        let range=EpsilonRange::new(0,count as i32-1)?;
        cache.insert(CachedBoundary {identity:engine.identity().clone(),point:CachedPoint::Exact(BTreeMap::from([(x,Atom::new())])),kind:PointKind::Physical,range,coefficients:values,accuracy:BoundaryAccuracy::supplied(40,p.bits,vec![vec![p.tolerance(45);n];count],"finite40digit source, independent old implementation comparison")?})?;
        let result=engine.evaluate_to(&mut cache,&BTreeMap::from([(x,end)]),range,&FlowOptions::default(),&RunContext::default(),&ScaledDistance {scales:BTreeMap::new(),admissible:|_:&CachedBoundary,_:&CachedPoint|Ok(true)})?;
        let solution=result.transport.as_ref().unwrap();
        writeln!(&mut output,"CASE {case} steps {} bits {} checkpoints {} entries {} verified {} input {}",solution.diagnostics.steps,solution.diagnostics.working_bits,solution.checkpoints.len(),cache.len(),result.boundary.accuracy.verified_digits(),result.boundary.accuracy.input_verified_digits()).unwrap();
        for (index,entry) in cache.entries().iter().enumerate() {
            writeln!(&mut output,"ENTRY {index} {:?} {} {}",entry.point.rounded_coordinates_as_exact()?,entry.accuracy.verified_digits(),entry.accuracy.input_verified_digits()).unwrap();
            for (value,error) in entry.coefficients.iter().flatten().zip(entry.accuracy.comparison_errors().iter().flatten()) {
                writeln!(&mut output,"{} {} {}",value.re.to_rational(),value.im.to_rational(),error.to_rational()).unwrap();
            }
        }
    }
    std::fs::write(std::env::args().nth(1).unwrap(),output).unwrap();
    Ok(())
}
