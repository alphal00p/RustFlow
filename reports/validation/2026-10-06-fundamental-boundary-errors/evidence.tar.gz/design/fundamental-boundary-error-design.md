# Signed fundamental boundary-error propagation: first bounded slice

Base: 59457c5eab62e81741b49b89e00da2c9fd5eb08f. This follows the unchanged-engine epsilon-singular probe 973ce9fc84e7b4783dc45e53a72ebb20dc07e70f. The probe and its archive stay immutable.

## Scope and ownership

Add an opt-in source-error propagation strategy, retaining scalar-norm default and fallback. First admit ordinary rational systems, including the one-channel finite-epsilon wrapper; the generic result is a componentwise source-error contribution at each accepted physical endpoint. Registered-root charts and multi-order epsilon hierarchies retain their current owner. No epsilon-singular sampling API or Laurent-tail assumption is introduced here.

Use CompiledSystem::taylor_channels for independent fundamental columns: with only shift-zero entries, its existing recurrence supplies arbitrary independent right-hand sides. Propagate P'=A P and Q'=-Q A (the latter via columns of Q^T against -A^T). Q is merely a numerical inverse candidate: its differential defect is not trusted. All products, derivatives and interval arithmetic use native Symbolica/Numerica Matrix, UnivariatePolynomial, ComplexBall and directed Float arithmetic. Existing ExactSourceResidual supplies the exact-source defect of P. No new recurrence, convolution, linear solver or transcendental enclosure implementation.

Build independent identity-coordinate proof charts along the same accepted physical straight segments. This avoids relying on the central Taylor/Padé approximation as a fundamental matrix and preserves the selected continuation path even if the central solution used local Möbius coordinates. There is initially no new proof-specific subdivision policy: inconclusive disks fall back. Saved intermediate endpoints get the same proof, and failed proof or physical admission commits no cache state.

## Exact mathematical contract

Let F solve F'=A F, F(start)=I, along the retained piecewise straight physical path. Stored source parameters remain their exact dyadics, as in the existing residual owner; uncertainty of physical inputs is a separate contract. Let P_k and Q_k be stored-dyadic matrix polynomials on proof chart k. Every disk includes the exact difference of its stored physical endpoints, converted outwards; do not silently substitute a rounded offset.

Keep the source's existing fixed positive component scales W=diag(w_i). All norms below are the infinity norm of W^-1 M W, bounded with directed real/imaginary one-norms. P(start)=I exactly. On each entire proof disk, certify

    eta_k >= ||I-Q_k P_k||_W, eta_k < 1/2.

Then P_k is invertible throughout the disk and

    ||P_k^-1 R_k||_W <= ||Q_k||_W ||R_k||_W / (1-eta_k),
    R_k=P_k'-A P_k.

R is enclosed against the retained exact rational source using ExactSourceResidual; original source guards are separately enclosed before cancellations. Its existing component integrated bounds combine into an outward matrix row norm. Multiplying Q and R before taking norms is a possible later tightening, not required for this slice.

P may jump at a chart boundary because a stored new constant was rounded. With left and right candidates P_- and P_+, use native endpoint balls to enclose

    J_k = P_+(0)^-1 (P_-(end)-P_+(0)),
    Z_+ = (I+J_k) Z_-, where F=P Z.

Bound J using the certified right-chart inverse. Q is allowed to jump freely because it only witnesses local invertibility. Retain the exact endpoint argument and native ball evaluation when measuring P's jump; evaluation rounding is part of the enclosure.

Accumulate over the complete path

    theta = sum_k integral ||P_k^-1 R_k||_W |dx| + sum_j ||J_j||_W.

Require theta <= 1/4. The Volterra equation with these jump terms has norm at most theta, hence the arithmetic-only Neumann bound

    ||Z-I||_W <= theta/(1-theta).

No exp/log/sqrt enclosure is asserted: pinned RealBall documents only arithmetic as certifying. The theta cap is an admission/conditioning policy; failure retains scalar fallback, never omits uncertainty.

For supplied component error bounds delta_j (including the existing source verified-digit floor), rho=max_j(delta_j/w_j), the endpoint error obeys

    error_i <= sum_j |P_ij| delta_j
               + w_i row_sum_j |(W^-1 P W)_ij| rho theta/(1-theta).

All endpoint values and matrix products are outward native balls. Signed matrix mixing is retained until these final absolute row bounds. Multiplying per-segment transfer norms would recreate exponential overestimation for nilpotent systems and is explicitly forbidden here.

## Resource and failure contract

Preflight dimensions, degree, coefficient objects, stored precision and estimated native product work before allocations; check cancellation between rows/native operations and around native calls. The first default dense admission is deliberately small (planned dimension <=16, subject to aggregate work/coefficients cap), configurable through validated options if exposed. Estimates are conservative admission estimates, not a hard allocator/time quota. Matrix input validation occurs before construction to avoid native dimension panics.

For n components and order m, storing P/Q alone requires 2*n^2*(m+1) complex coefficients; polynomial inverse/defect products add O(n^2*m), and dense native products cost O(n^3*m^2) in the worst case. At n=61,m=112, P/Q alone is 840,946 complex coefficients before ball/product temporaries; a flattened five-order hierarchy would require over 21 million. Do not silently allocate such a hierarchy. Existing epsilon sparsity should be reused in a later owner before increasing scope.

Unsupported system kinds, exceeded optional budgets, excluded/convergence disks, unresolved inverse or theta bounds return an explicit unavailable-proof diagnostic and retain scalar source-error handling. Cancellation and malformed inputs propagate their typed errors. Precision retries create fresh source coefficients and fresh proof charts. Source evidence floors/caps, central independent order/precision checks, conditioning and cache provenance are unchanged.

## Verification plan

1. Nilpotent N/epsilon example N=[[1,1],[-1,-1]], N^2=0: exact I+xN/epsilon reference and source uncertainty remain finite at the recorded rational sample spacings. Use independent central precision/order refinement and a full physical/cache route, not only a proof helper.
2. Genuinely amplifying scalar/diagonal A=lambda/epsilon: the new bound must retain physical exponential growth and reject an inadequate source. No exact matrix-property special case.
3. Multiple accepted charts with nonrepresentable endpoint values: verify signed global composition and nonzero rounding-jump contribution; independent analytic or high-precision comparison.
4. Noncommuting rational matrix with manufactured exact fundamental solution; complex path and source coefficients; mapped central charts and saved endpoints.
5. Ill-conditioned/singular inverse candidate, denominator holes (including cancelled domains), precision refinement, dimension/work limits, cancellation and atomic failed cache state.
6. Exact repeated cache hit/restart retains evidence and source caps; defaults remain equivalent to explicit scalar strategy.

Performance is initially an overhead measurement only. This feature addresses generic conditioning/uncertainty admission; it does not establish overall AMFlow/DiffExp parity or solve sampled-boundary and error-aware Laurent fitting requirements.
