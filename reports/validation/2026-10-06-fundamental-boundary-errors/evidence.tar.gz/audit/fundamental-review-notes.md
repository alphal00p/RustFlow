# Independent scoped review

The parent reviewed the mathematical contract and physical transport plumbing: signed global P, local Q inverse witnesses, exact stored-endpoint differences, jump terms, weighted Neumann bound and original source guards. Public physical transport/cache tests were requested in addition to private proof tests and are included.

The independent community integration agent reviewed native ownership and arithmetic without builds or edits. Its first review found no mathematical blocker but identified that the resource estimate omitted retained endpoint errors. That finding was addressed before the final source freeze.

Final resource re-review on 2026-10-06 inspected `src/ode/fundamental.rs` SHA-256 `7bea2e9061571fee8bb8b3960cc477bc46258f71f4a6ae606abbaee1514f9c5b`: retained charts*n Float cells and per-chart Vec headers are charged before allocation at actual precision; guard shift work/storage and exact transpose storage are included; whole-column metadata preflight precedes preparation; and output degree/height has a typed postcheck. The 600,000-chart 160/4,096-bit regression targets the reported omission. No remaining blocker was found in this scoped source review. Admission estimates are not hard native allocation/runtime quotas.

These are source reviews, not independent executions of the runtime gates. The gate logs and exact frozen source are archived separately.
