# Propagating supplied boundary uncertainty

`FlowOptions::boundary_error_strategy = BoundaryErrorStrategy::FundamentalMatrix` opts into a bounded signed fundamental-matrix proof for ordinary rational physical transport. Python `EvaluationOptions` and CLI settings accept `boundary_error_strategy="fundamental_matrix"`; the default remains `"scalar_norm"`.

The central trajectory still passes its ordinary source-defect, conditioning and independent precision/order checks. The new policy controls how the separately supplied boundary errors are propagated. It does not upgrade the input's recorded accuracy or interpret storage precision as evidence.

The first slice supports specialized ordinary rational systems, including a single finite-epsilon sample expressed as one coefficient row. Multiple epsilon orders, registered roots, sources with unspecialized parameter maps and proof resource limits retain the existing scalar error estimate. This is not an automatic finite-epsilon fallback for epsilon-singular bases. That workflow still needs authenticated finite-epsilon boundary data, error-aware Laurent fitting, and automatic selection of this stronger proof when the scalar bound would reject.

For a system `Y'=A(x)Y`, the proof propagates a signed global matrix candidate `P` from the identity using the existing batched Taylor recurrence. An inverse candidate `Q` uses the same recurrence on `-A^T`. Native Symbolica/Numerica matrix and ball-polynomial products certify `||I-QP||<1/2` over every whole chart. The retained exact source supplies an outward bound on `R=P'-AP`. Rounded changes of `P` between charts contribute an explicit jump term.

If the cumulative transformed-defect and jump bound is `theta<=1/4`, the true fundamental matrix has the form `F=P Z`, with `||Z-I||<=theta/(1-theta)` in the existing fixed weighted norm. The final matrix row bounds propagate the supplied component errors. Signed mixing remains intact until these final absolute bounds; individual segment norms are never multiplied. The proof uses certified native arithmetic only, without assuming certified native exponential or logarithm functions.

The proof independently uses identity-coordinate charts along the accepted physical segments. A central Möbius or rational-approximant chart is therefore compatible, but does not itself become an inverse witness. Original source exclusions are checked separately from cancelled equations. An inconclusive disk, inverse, cumulative bound or optional budget retains the scalar fallback; cancellation and malformed inputs remain typed failures. No failed trajectory inserts cache entries.

Dense admission is deliberately bounded: dimension at most 16, order at most 256 and working precision at most 4096 bits, with further cumulative coefficient/work and 256 MiB storage estimates and exact source-expression checks. These are conservative admission estimates, not hard allocation or runtime quotas. At dimension 61 and order 112, the two candidate matrices alone would contain 840,946 complex coefficients, before inverse-product and defect temporaries. A hierarchy should reuse its existing sparse structure before widening this scope.

`TransportResult.fundamental_boundary_charts` reports successful proof charts; `fundamental_boundary_fallback` records why scalar handling was retained. Cached values retain the proof method in their provenance and preserve their existing accuracy caps. The strategy changes verification policy, not the mathematical cache identity or binary format, so a verified result remains reusable across strategies.

This addresses a general uncertainty overestimate; it does not establish feature or performance parity with the reference packages. Kernel, whole-transport and full-physics timings must remain separate.
