import copy
import hashlib
import json
from pathlib import Path
from symbolica import E
from symbolica.community.hepkit import Model

root = Path('/common/dev/amflow-standard-model')
fixture = root / 'fixtures/gg-hg'
asset_path = fixture / 'form-factor-vertices.json'
asset = json.loads(asset_path.read_bytes())
legacy_definition = json.loads((fixture / 'native-model.json').read_bytes())
legacy = Model.from_json(json.dumps(legacy_definition))
sm = Model.standard_model()
original = json.loads(sm.to_json())
extended = copy.deepcopy(original)
sections = ['orders', 'parameters', 'couplings', 'lorentz_structures', 'vertex_rules']
for section in sections:
    records = copy.deepcopy(asset[section])
    existing = {item['name'] for item in original[section]}
    assert not existing.intersection(item['name'] for item in records)
    if section == 'vertex_rules':
        for item in records:
            item['particles'] = [sm.particle_by_pdg(21).name] * 3 + [sm.particle_by_pdg(25).name]
    extended[section].extend(records)
model = Model.from_json(json.dumps(extended))
restored = json.loads(model.to_json())
checks = {}
for section in sections:
    expected = {item['name']: item for item in original[section]}
    actual = {item['name']: item for item in restored[section]}
    checks['original_' + section] = all(actual[name] == item for name, item in expected.items())
for key in original.keys() - set(sections):
    checks['original_' + key] = original[key] == restored[key]
checks['vev_relation'] = (sm.parameter('vev').expression - legacy.parameter('v').expression).cancel() == E('0')
for name in ['CHEFT', 'AllGGGHEWWWCoup', 'AllGGGHEWZZCoup']:
    expected = legacy.parameter(name).expression.replace(legacy.parameter('v').symbol, sm.parameter('vev').symbol)
    checks['exact_prefactor_' + name] = (model.parameter(name).expression - expected).cancel() == E('0')
for item in asset['couplings']:
    name = item['name']
    checks['exact_coupling_' + name] = (model.coupling(name).expression - legacy.coupling(name).expression).cancel() == E('0')
for section in ['orders', 'lorentz_structures', 'vertex_rules']:
    originals = {item['name']: item for item in legacy_definition[section]}
    checks['unchanged_declarations_' + section] = all(item == originals[item['name']] for item in asset[section])
checks['no_new_particles'] = len(model.particles) == len(sm.particles)
checks['numeric_defaults_not_imported'] = all(x['value'] is None for x in asset['couplings']) and all(x['value'] == ([0.0, 0.0] if x['nature'] == 'external' else None) for x in asset['parameters'])
assert all(checks.values()), [key for key, value in checks.items() if not value]
report = {
    'status': 'passed',
    'scope': 'Existing native Python 7096 runtime: in-memory SM+declaration native reload, exact native Symbolica prefactor/coupling identities and preserved original SM content; no amplitude evaluation or native build.',
    'native_runtime_pin': '7096ba8e1f4d7edda4402f9ff01c961f6f3e6a4e',
    'checks': checks,
    'check_count': len(checks),
    'counts': {section: len(asset[section]) for section in sections},
    'source_hashes': {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [asset_path, fixture / 'form-factor-vertices-provenance.json', fixture / 'native-model.json', root / 'scripts/extract_gg_hg_form_factor_vertices.py']},
}
(root / 'target/gg-hg-standard-model-asset-validation/report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'checks': report['check_count'], 'counts': report['counts']}, indent=2))
