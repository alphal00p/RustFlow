use pyo3::types::PyModule;

#[path = "/common/dev/symbolica-community/notebook-supplied-boundaries/src/bin/stub_gen/compat.rs"]
mod compat;

fn main() {
    pyo3::Python::initialize();
    pyo3::Python::attach(|py| {
        let module = PyModule::new(py, "symbolica.community.hep.integration").unwrap();
        symbolica_amflow::python::register(&module).unwrap();
    });
    let info = pyo3_stub_gen::StubInfo::from_project_root(
        "symbolica.core".into(),
        env!("CARGO_MANIFEST_DIR").into(),
    )
    .unwrap();
    let raw = info.modules["symbolica.community.hep.integration"].to_string();
    let compatible = compat::python_39_stub_source(&raw);
    let text = compatible
        .lines()
        .map(str::trim_end)
        .collect::<Vec<_>>()
        .join("\n");
    std::fs::write(
        std::env::args().nth(1).expect("output path"),
        text.trim_end().to_owned() + "\n",
    )
    .unwrap();
}
