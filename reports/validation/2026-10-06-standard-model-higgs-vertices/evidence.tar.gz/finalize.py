from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import tarfile

root = Path.cwd()
evidence = root / 'target/standard-model-validation'
report_dir = root / 'reports/validation/2026-10-06-standard-model-higgs-vertices'
report_dir.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = json.loads((evidence / 'source-inputs.json').read_text())
assert all(sha(root / name) == digest for name, digest in inputs['files'].items())
stub = evidence / 'integration.pyi'
stub_text = stub.read_text()
ast.parse(stub_text, feature_version=(3, 9))
assert 'def with_form_factor_vertices(' in stub_text
assert not (root / 'examples/_generate_integration_stub.rs').exists()

logs = {
    'native_amplitude': root / 'target/standard-model-amplitude-test-v2.log',
    'native_clippy': root / 'target/standard-model-clippy.log',
    'python': root / 'target/standard-model-python-test.log',
    'python_clippy': evidence / 'python-clippy.log',
    'stub_build': evidence / 'stub-build.log',
    'stub_generation': evidence / 'stub-generation.log',
    'asset_check': evidence / 'asset-check.log',
    'format': evidence / 'format.log',
    'diff_check': evidence / 'diff-check.log',
}
assert 'test result: ok. 2 passed; 0 failed; 0 ignored;' in logs['native_amplitude'].read_text()
assert 'test result: ok. 4 passed; 0 failed; 1 ignored;' in logs['python'].read_text()
for key in ['native_clippy', 'python_clippy', 'stub_build']:
    text = logs[key].read_text()
    assert 'Finished `release`' in text and 'error:' not in text
for key in ['stub_generation', 'format', 'diff_check']:
    assert logs[key].read_text() == ''
assert logs['asset_check'].read_text().count('Checked fixtures/') == 2
compat = Path('/common/dev/symbolica-community/notebook-supplied-boundaries/src/bin/stub_gen/compat.rs')
assert sha(compat) == '7403ca0f0d027b7607a1346d297572a49e3a09ed6b78bcf00c1114392dbd19c9'
(evidence / 'stub-compat.rs').write_bytes(compat.read_bytes())
archive = report_dir / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in logs.items():
        tar.add(path, arcname=f'logs/{name}.log')
    for name in ['source-inputs.json', 'generate_integration_stub.rs', 'stub-compat.rs', 'integration.pyi', 'finalize.py']:
        tar.add(evidence / name, arcname=name)
    for name in ['standard-model-amplitude-test.log', 'standard-model-python-test-launch-error.log']:
        tar.add(root / 'target' / name, arcname=f'development/{name}')
    for name in ['report.json', 'validate.py', 'validation.log']:
        tar.add(root / 'target/gg-hg-standard-model-asset-validation' / name, arcname=f'prior-asset-validation/{name}')
report = {
    'base_commit': inputs['base'],
    'scope': 'Extend native Model.standard_model with minimal symbolic ggHg form-factor declarations and credit successfully prepared numerical methods/scientific inputs through native cumulative Citation records.',
    'validation': {
        'native_amplitude': '2 passed; exact equality of all three kernels with the legacy scientific model, native graph/model sharing, original SM preservation and collision rejection.',
        'python_stubgen': '4 passed; process-isolated cumulative citations including import/failed-preparation controls, native Model interoperability, generated method stubs and supplied boundary precision/restart.',
        'ignored_python_test': 'all_packaged_higgs_values_enter_the_current_native_evidence_path requires the independent community loader/bundle; it was not run in this focused gate.',
        'strict_release_clippy': 'Native lib/amplitude gate and python_stubgen lib/python_portable_higgs_seeds gate passed with -D warnings.',
        'format_and_diff': 'passed',
        'scientific_asset_regeneration': 'Both committed declaration/provenance assets reproduced byte-for-byte with --check.',
        'stub': 'Generated from the current Rust python_stubgen metadata, normalized by the community host compatibility owner, and parsed with Python3.9 grammar.',
    },
    'pins': {'symbolica': '6defcca968ca8411977fb1f641a9dee49ee7b7a7', 'hepkit': 'b96600b0085d9ddfa9e6acbc11fa72ec6163253c', 'rustred': '7c1ed03722b8c05daf60c89ba4ecc79457ed2ada'},
    'cargo_lock_sha256': sha(root / 'Cargo.lock'),
    'source_inputs': inputs,
    'stub_sha256': sha(stub),
    'stub_compat_sha256': sha(compat),
    'stub_generator_sha256': sha(evidence / 'generate_integration_stub.rs'),
    'log_sha256': {name: sha(path) for name, path in logs.items()},
    'remaining_runtime_validation': 'The new complete community native/WASM notebook builds and notebook-level citation aggregation are separate host gates. This report does not claim that the previously validated browser wheel contains this new API.',
    'development_evidence': 'Retained initial Process::new selector type error and invalid taskset invocation; corrected runs are the accepted gates above. Earlier33-check asset validation uses the prior7096 native runtime and is separately labeled.',
    'compiler': subprocess.check_output(['rustc', '--version'], text=True).strip(),
    'commands': [
        'cargo test --locked --release -j2 --test gg_hg_amplitude',
        'cargo test --locked --release -j2 --features python_stubgen --test python_portable_higgs_seeds',
        'cargo clippy --locked --release -j2 --features python_stubgen --lib --test python_portable_higgs_seeds -- -D warnings',
        'cargo rustc --locked --release -j2 --features python_stubgen --example _generate_integration_stub -- -C opt-level=0 -C lto=off',
        'CARGO_TARGET_DIR/release/examples/_generate_integration_stub target/standard-model-validation/integration.pyi',
        'python scripts/extract_gg_hg_form_factor_vertices.py --check',
        'cargo fmt --all --check',
        'git diff --check',
    ],
    'python_target': '/common/dev/amflow/target/standard-model-native-host',
    'python_interpreter': '/common/dev/amflow/target/gg-hg-browser-seeds/native-venv/bin/python',
    'archive': {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size},
}
(report_dir / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
(report_dir / 'README.md').write_text('''# Native Standard Model form factors and numerical-method citations

The effective ggHg declarations now extend HEPKit's native Standard Model through
its model interchange. Original SM data is preserved, declaration collisions
fail, and particle selection uses PDG identities. The declarations contain
symbolic tensors/couplings and zero placeholders, not numerical loop results.
Native scientific/methodological citations are cumulative and activate only
after successful preparation; the community host can merge the returned native
Citation records into Symbolica's existing registry.

Validation passed: two native amplitude tests, four Python/stub tests, focused
strict release Clippy, formatting/diff checks and exact asset regeneration.
The three Standard Model scalar kernels equal the legacy kernels exactly.
Python tests cover native model ownership, rejected collisions, six isolated
citation scenarios and exact supplied-boundary restart. One independent
community-bundle acceptance test remains explicitly ignored in this gate.

The generated integration stub uses the host's compatibility normalizer and
passes Python3.9 syntax parsing. Its generator is archived; the temporary Cargo
example was removed. Production changes and fixture hashes remain those frozen
before the native/Python gates.

See [report.json](report.json) and [evidence.tar.gz](evidence.tar.gz) for commands,
source/asset/stub hashes and accepted logs. Earlier development failures and the
old-runtime asset-only validation are preserved separately. New shared-host
native/browser notebook acceptance is a subsequent host gate; this milestone
does not claim the existing browser wheel already includes the new APIs.
''')
print(json.dumps({'report': str(report_dir), 'stub_sha256': report['stub_sha256'], 'archive': report['archive']}))
