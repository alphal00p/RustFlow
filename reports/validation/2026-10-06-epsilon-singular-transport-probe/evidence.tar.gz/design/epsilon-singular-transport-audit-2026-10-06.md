# Design audit: sampled transport beyond diagonal epsilon shearing

Status: read-only audit against main 6a774c0; no implementation or numerical claim.
PreparedRows milestone is separately committed/pushed as 1d4e241.

## Concrete gap and analytic acceptance case

`Connection::pullback` in `src/physical_transport.rs` always constructs an
`EpsilonSystem` (or its registered-root analogue) before integration.
`EpsilonShearing::regularize` solves only common diagonal valuation constraints.
A negative cycle correctly refuses that restricted gauge class, even if a
nondiagonal gauge exists.

A minimal genuinely coupled example is

```
dI/dx = N I / epsilon,  N = [[1, 1], [-1, -1]],  N^2 = 0.
I(0, epsilon) = (1, 0)
I(x, epsilon) = (1 + x/epsilon, -x/epsilon).
```

The diagonal epsilon poles prevent any diagonal rescaling, but the solution is
meromorphic with pole bound -1. A constant exact change of basis makes N strictly
triangular, confirming that this is a representation limitation, not an essential
singularity. Use exact native matrix multiplication/change_basis to certify the
fixture. A second test should start from an epsilon-regular, noncommuting system
and apply an explicitly known nondiagonal rational gauge. Include physical-variable
dependence in the gauge to exercise the derivative term when comparing results.

The scalar equation `I' = I/epsilon`, with I(0)=1, is the contrasting essential
singularity. Finite-epsilon transport is meaningful, but Laurent reconstruction
requires a meromorphy/pole-bound contract; fit stability is not proof of that
contract. Do not advertise a general essential-singularity detector.

## Reuse existing owners

- Keep `KinematicSystem`/`AlgebraicKinematicSystem` as exact connection owners.
  Simultaneously specialize epsilon to an exact nonzero Rational before the
  direct hierarchy constructor. `DifferentialSystem::compile` and the shared
  `ode::SeriesSystem` controller already integrate the resulting ordinary ODE.
  Registered epsilon-independent roots can use a single-channel AlgebraicSystem;
  retain root normalization, RootGerm, accepted branch state and fresh compilation.
- Reuse physical path planning, HomotopyAdmission and exact domain owners. A raw
  matrix or reduction guard such as s-epsilon must be specialized and checked at
  EACH requested epsilon before source selection/path continuation. Generic
  common-zero testing alone does not see a moving finite-epsilon pole. Retain
  original source holes and current physical Laurent-chart exclusions; this
  milestone should not relax those domains.
- Reuse `PreparedFlow::evaluate`, `evaluate_samples`, recursive boundary providers,
  exact target projection and AMF/FT selection for actual integral boundaries.
  Fresh finite-epsilon values are required, not evaluation of an existing truncated
  Laurent polynomial at epsilon. Existing compiled sources must be regenerated at
  every precision refinement as they are today.
- Keep Symbolica responsible for exact substitution, polynomial arithmetic, matrix
  solving/inversion, native series, roots and directed balls. No second ODE kernel,
  custom interpolation elimination, graph algebra or tensor owner is needed.

## Boundary and accuracy contracts that must be added

`CachedBoundary` stores a finite Laurent prefix and coefficient accuracy, with no
bound on the omitted tail. It cannot safely initialize this fallback by polynomial
evaluation. `CompletedSample` in `sample_checkpoint.rs` is deliberately restart-only
and has no inherited source-error evidence. Neither object can be relabeled as a
verified finite-epsilon physical boundary.

Add a distinct finite-epsilon boundary value record/provider with exact epsilon,
ordered basis identity, point/root germ, component values, absolute error evidence,
precision and provenance. A prepared integral family can provide these by fresh
AMF/FT evaluation and independent precision/order comparison; a supplied system
must provide equivalent sample evidence explicitly. A finite Laurent boundary is
usable only if accompanied by an explicit valid remainder bound or an exact
finite-support declaration, both checked before interpolation.

For Laurent reconstruction, require a documented meromorphic solution/pole-bound
contract. Ordinary prepared families inherit the existing dimensional-regulated
integral contract and basis factors; generic supplied systems need an explicit
contract/certificate, such as an exact rational gauge to an epsilon-regular
connection. This is a condition on the selected solution, not merely the matrix.

`fit_samples_refined_leading` currently receives only central sample values and
compares independent grids/precision/order. A sampled physical route must also
propagate input and transport errors into the fit. Factor a shared fitting owner
that obtains the requested coefficient rows of the interpolation map from native
exact Rational matrices (or an equivalently validated native numerical solve).
Use absolute interpolation weights to carry component sample errors, plus current
fit/refinement and arithmetic error evidence. Bound matrix dimensions/height/work
before native operations. Preserve source accuracy caps and fail if conditioning
amplifies errors beyond the requested tolerance; do not assign working precision
as achieved accuracy. Target reduction coefficients and normalization factors are
applied to finite-epsilon values and their errors before fitting.

There is a major conditioning risk: the current physical input-error majorant uses
an exponential of an integrated weighted matrix norm (finite Dyson truncation only
for a strictly positive epsilon hierarchy). Applied to N/epsilon it may grow as
exp(c/epsilon), although the exact transfer is I+xN/epsilon. Therefore a functional
fallback alone does not guarantee practical generality. First measure this analytic
case with the unchanged conservative majorant. If it refuses useful accuracy, a
separate reviewed transfer/error-bound improvement is needed, potentially using
native matrix fundamental solutions and existing exact source defect checks. Never
silently discard inherited source uncertainty to make the example pass.

## Progressive cache and restart

Keep finite-epsilon samples as a separately typed collection in the shared
BoundaryCache/RustFlowCache owner, never as Laurent or terminal endpoint entries.
Use source-sensitive keys covering original connection/basis, exact epsilon,
physical coordinates/root sheet, continuation declaration, source evidence and
numerical profile. Ordinary nearest-source selection must not consume them.
Per-epsilon selection can reuse the existing geometric/cost/homotopy policies.
Unverified completed samples remain restart data; verified sample boundary records
need their own evidence validation. Binary codec evolution must reject older
incompatible entries and write atomically, following the existing cache owner.

Accepted finite-epsilon checkpoints are useful and may be accumulated per epsilon.
Their adaptive chart nodes will differ across epsilon values. To create a Laurent
boundary at an intermediate point, evaluate every required sample/refinement on a
common exact physical checkpoint and verify its propagated error before fitting.
Alternatively retain unmatched points only in the sample collection; future sample
queries can still choose them independently. Never combine different physical
points into one Laurent fit. Preserve precision-profile separation and allow
restart of completed samples without promoting them into independent validation.

## Proposed first implementation slice after approval

1. Explicit sampled physical API and exact nonzero-epsilon boundary/provider
   records; ordinary shared ODE transport, prescribed-route and guard validation.
   No implicit fallback from a truncated CachedBoundary.
2. Shared error-aware finite-sample fit, with explicit meromorphy/pole-bound
   admission; wire a PreparedPhysicalFamily boundary provider through AMF/FT.
3. Separately typed progressive sample persistence/source selection and common
   intermediate-point Laurent reconstruction; keep endpoint handling outside this
   first regular-physical transport slice.
4. Descriptive Python/CLI controls and provenance after Rust validation. Preserve
   current direct-hierarchy/default behavior; only choose sampled transport when
   requested or when an automatic family path has the required provider/contract.

Required tests include the nilpotent negative-cycle case and exact nondiagonal
reference gauge, the essential-singularity contract refusal, missing Laurent-tail
refusal, tiny input uncertainty amplified by fitting, exact complex kinematics,
finite-epsilon moving poles and cancelled source holes, source/target projection
before fit, registered-root sheet consistency, fresh precision/order recompilation,
interruption/restart, repeated exact sample hits, and nearby point selection.
Measure cold AMF seeding, sampled continuation, independent fit refinement, resumed
runs and warm cache hits separately. Any failure of the existing amplification
majorant must remain explicit and cannot be recast as a successful generic fallback.
