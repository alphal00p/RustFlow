"""Independent stricter exact-rational review of the compact transport profile."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import sys

base, probe = map(Path, sys.argv[1:3])
a, b = [json.loads(p.read_text()) for p in [base, probe]]
for key in ['source_digest', 'dependency_digest', 'input_blake3', 'origin', 'rustred_runtime_arities']:
    assert a[key] == b[key], key
assert b['settings'] == dict(a['settings'], guard_digits=30, series_order=32)
count = cache_count = 0
for x, y in zip(a['cases'], b['cases'], strict=True):
    assert x['label'] == y['label'] and x['starting_coordinates'] == y['starting_coordinates']
    assert 'steps: 1, rejected_steps: 0' in y['diagnostics']
    assert 'working_bits: 249, expansion_order: 64' in y['diagnostics']
    for xb, yb in [(x['boundary'], y['boundary']), *zip(x['new_cache_entries'], y['new_cache_entries'], strict=True)]:
        for key in ['coordinates', 'root_germ', 'leading', 'last', 'verified_digits', 'input_verified_digits', 'provenance']:
            assert xb[key] == yb[key], key
        assert 20 <= yb['verified_digits'] <= yb['input_verified_digits'] <= 40
        for xv, yv, xe, ye in zip(xb['coefficients'], yb['coefficients'], xb['comparison_errors'], yb['comparison_errors'], strict=True):
            for xc, yc, ex, ey in zip(xv, yv, xe, ye, strict=True):
                xr, xi, yr, yi = map(F, [xc[0][0], xc[1][0], yc[0][0], yc[1][0]])
                ex, ey = F(ex[0]), F(ey[0])
                # L1 difference >= Euclidean; max-component scale <= Euclidean.
                delta = abs(xr - yr) + abs(xi - yi)
                assert delta <= ex + ey
                for r, i, error in [(xr, xi, ex), (yr, yi, ey)]:
                    scale = max(F(1), abs(r), abs(i))
                    assert 0 <= error <= scale / F(10**20) and delta <= scale / F(10**20)
                if xb is x['boundary']:
                    count += 1
                else:
                    cache_count += 1
assert count == 4360 and cache_count == 8720
factor_count = 0
for x, y in zip(a['form_factors'], b['form_factors'], strict=True):
    assert x['mass'] == y['mass'] and x['verified_relative_digits'] == y['verified_relative_digits']
    for xc, yc, xe, ye in zip(x['values'][0], y['values'][0], x['absolute_errors'], y['absolute_errors'], strict=True):
        xr, xi, yr, yi, xe, ye = map(F, [xc[0][0], xc[1][0], yc[0][0], yc[1][0], xe[0], ye[0]])
        delta = abs(xr - yr) + abs(xi - yi)
        assert delta <= xe + ye
        for r, i, error in [(xr, xi, xe), (yr, yi, ye)]:
            assert 0 <= error <= max(abs(r), abs(i)) / 10**20
            assert delta <= max(abs(r), abs(i)) / 10**20
        factor_count += 1
for x, y in zip(a['observables'], b['observables'], strict=True):
    assert x['label'] == y['label'] and x['verified_relative_digits'] == y['verified_relative_digits'] >= 20
    xv, yv, xe, ye = map(F, [x['value'][0], y['value'][0], x['absolute_error'][0], y['absolute_error'][0]])
    assert abs(xv - yv) <= xe + ye
    assert 0 <= xe <= abs(xv) / 10**20 and 0 <= ye <= abs(yv) / 10**20
    assert abs(xv - yv) <= min(abs(xv), abs(yv)) / 10**20
result = {
    'independent_review_passed': True,
    'checker': 'exact Fraction L1 difference and conservative max-component requested-tolerance checks',
    'final_master_coefficients': count,
    'cached_complex_coefficients': cache_count,
    'form_factors': factor_count,
    'observable_verified_digits': [x['verified_relative_digits'] for x in b['observables']],
    'probe_sha256': hashlib.sha256(probe.read_bytes()).hexdigest(),
    'baseline_sha256': hashlib.sha256(base.read_bytes()).hexdigest(),
    'timing_caveat': 'CPU44 lower profile versus CPU43 baseline, one native run each on shared host; no WASM timing claim',
}
Path(sys.argv[3]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
