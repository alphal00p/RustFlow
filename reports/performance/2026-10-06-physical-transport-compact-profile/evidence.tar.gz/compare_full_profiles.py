"""Check two independently admitted profiles using exact rational arithmetic."""
import json
import sys
from fractions import Fraction
from pathlib import Path

high = json.loads(Path(sys.argv[1]).read_text())
low = json.loads(Path(sys.argv[2]).read_text())
for key in ("source_digest", "dependency_digest", "input_blake3", "origin", "rustred_runtime_arities"):
    assert high[key] == low[key], key
assert high["settings"]["digits"] == low["settings"]["digits"] == 20
assert high["settings"]["workers"] == low["settings"]["workers"] == 1

def rational(value):
    return Fraction(value[0])

def check_boundary(a, b):
    for key in ("coordinates", "root_germ", "leading", "last", "input_verified_digits", "provenance"):
        assert a[key] == b[key], key
    assert 20 <= a["verified_digits"] <= a["input_verified_digits"] <= 40
    assert 20 <= b["verified_digits"] <= b["input_verified_digits"] <= 40
    count = 0
    max_consistency_squared = Fraction(0)
    max_requested_squared = Fraction(0)
    max_error_requested_squared = Fraction(0)
    for va, vb, ea, eb in zip(a["coefficients"], b["coefficients"], a["comparison_errors"], b["comparison_errors"], strict=True):
        for za, zb, ax, bx in zip(va, vb, ea, eb, strict=True):
            ar, ai = map(rational, za)
            br, bi = map(rational, zb)
            ae, be = rational(ax), rational(bx)
            assert ae >= 0 and be >= 0
            delta_squared = (ar-br)**2 + (ai-bi)**2
            bound_squared = (ae+be)**2
            assert delta_squared <= bound_squared, "profiles exceed combined admitted errors"
            for r, i, error in [(ar, ai, ae), (br, bi, be)]:
                tolerance_squared = max(Fraction(1), r*r+i*i) / 10**40
                assert error*error <= tolerance_squared, "admitted error exceeds requested20 tolerance"
                assert delta_squared <= tolerance_squared, "profile difference exceeds requested20 tolerance"
                max_requested_squared = max(max_requested_squared, delta_squared/tolerance_squared)
                max_error_requested_squared = max(max_error_requested_squared, error*error/tolerance_squared)
            if bound_squared:
                max_consistency_squared = max(max_consistency_squared, delta_squared/bound_squared)
            count += 1
    return {
        "complex_coefficients_checked": count,
        "all_differences_within_combined_admitted_errors": True,
        "both_profiles_errors_and_differences_meet_requested20": True,
        "max_squared_difference_over_combined_bound": str(max_consistency_squared),
        "max_squared_difference_over_requested_tolerance": str(max_requested_squared),
        "max_squared_admitted_error_over_requested_tolerance": str(max_error_requested_squared),
    }

assert len(high['cases']) == len(low['cases']) == 16
assert high['final_cache_entries']==low['final_cache_entries']
assert high['all_observables_meet_requested20'] and low['all_observables_meet_requested20']
cases=[]
for a,b in zip(high['cases'],low['cases'],strict=True):
    assert a['label']==b['label']
    assert a['starting_coordinates']==b['starting_coordinates']
    assert a['inserted_points']==b['inserted_points']
    item=check_boundary(a['boundary'],b['boundary'])
    item['new_cached_boundaries']=[check_boundary(x,y) for x,y in zip(a['new_cache_entries'],b['new_cache_entries'],strict=True)]
    item.update({'label':a['label'],'high_seconds':a['transport_seconds'],'low_seconds':b['transport_seconds'],'ratio':a['transport_seconds']/b['transport_seconds'],'high_diagnostics':a['diagnostics'],'low_diagnostics':b['diagnostics'],'high_verified_digits':a['boundary']['verified_digits'],'low_verified_digits':b['boundary']['verified_digits'],'input_verified_digits':b['boundary']['input_verified_digits']})
    cases.append(item)
assert sum(c['complex_coefficients_checked'] for c in cases)==4360

def compare_relative(ar,ai,ae,br,bi,be):
    ar,ai,ae,br,bi,be=map(Fraction,[ar,ai,ae,br,bi,be])
    delta=(ar-br)**2+(ai-bi)**2
    assert ae>=0 and be>=0
    assert delta<=(ae+be)**2
    for r,i,error in [(ar,ai,ae),(br,bi,be)]:
        norm=r*r+i*i
        assert norm>0
        assert error*error<=norm/10**40
        assert delta<=norm/10**40
    return {'within_combined_admitted_errors':True,'both_admitted_errors_and_difference_meet20_relative_digits':True,'squared_difference':str(delta),'squared_combined_error':str((ae+be)**2)}

factors=[]
for a,b in zip(high['form_factors'],low['form_factors'],strict=True):
    assert a['mass']==b['mass'] and a['provenance']==b['provenance']
    assert all(n is not None and n>=20 for n in a['verified_relative_digits']+b['verified_relative_digits'])
    comparisons=[]
    for va,vb,ea,eb in zip(a['values'][0],b['values'][0],a['absolute_errors'],b['absolute_errors'],strict=True):
        comparisons.append(compare_relative(va[0][0],va[1][0],ea[0],vb[0][0],vb[1][0],eb[0]))
    factors.append({'mass':a['mass'],'high_verified_relative_digits':a['verified_relative_digits'],'low_verified_relative_digits':b['verified_relative_digits'],'coefficients':comparisons})
observables=[]
for a,b in zip(high['observables'],low['observables'],strict=True):
    assert a['label']==b['label']
    assert a['verified_relative_digits']>=20 and b['verified_relative_digits']>=20
    item=compare_relative(a['value'][0],0,a['absolute_error'][0],b['value'][0],0,b['absolute_error'][0])
    item.update({'label':a['label'],'high_verified_relative_digits':a['verified_relative_digits'],'low_verified_relative_digits':b['verified_relative_digits'],'high_reference_relative_difference':a['reference_relative_difference'],'low_reference_relative_difference':b['reference_relative_difference']})
    observables.append(item)
ht=sum(c['transport_seconds'] for c in high['cases'])
lt=sum(c['transport_seconds'] for c in low['cases'])
report={'comparison':'full16 shared cache,4360 final master coefficients,8 form factors and3 native observables; exact rational error comparisons','source_digest':high['source_digest'],'dependency_digest':high['dependency_digest'],'input_blake3':high['input_blake3'],'high_settings':high['settings'],'low_settings':low['settings'],'high_total_transport_seconds':ht,'low_total_transport_seconds':lt,'transport_ratio':ht/lt,'transport_reduction_percent':100*(1-lt/ht),'high_form_factor_seconds':high['form_factor_seconds'],'low_form_factor_seconds':low['form_factor_seconds'],'high_amplitude_seconds':high['amplitude_seconds'],'low_amplitude_seconds':low['amplitude_seconds'],'high_setup_seconds':high['setup_seconds'],'low_setup_seconds':low['setup_seconds'],'final_cache_entries':high['final_cache_entries'],'cases':cases,'form_factors':factors,'observables':observables,'all_observables_meet_requested20':True,'reference_note':high['reference_note']}
Path(sys.argv[3]).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['cases','form_factors','observables']},indent=2))
print(json.dumps([{k:v for k,v in x.items() if not k.startswith('squared_')} for x in observables],indent=2))
