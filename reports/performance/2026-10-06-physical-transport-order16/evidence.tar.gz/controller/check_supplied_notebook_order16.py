"""Frozen native notebook-controller acceptance with supplied starting values."""
import json
from pathlib import Path
import sys
from time import perf_counter

SOURCE = Path('/common/dev/symbolica-community/notebook-supplied-boundaries/examples/hep')
sys.path.insert(0, str(SOURCE))
from gg_hg_support import CalculationSession, boundary_evidence
from gg_hg_acceptance import (
    runtime_attestation, verify_runtime_attestation, file_attestation,
    load_comparison_reference, check_transport_reference_coverage, compare_form_factors,
)
from symbolica import ComplexFloat, Float

output = Path(sys.argv[1])
output.mkdir(exist_ok=False)
runtime = runtime_attestation()
data = SOURCE / 'data/gg_hg'
session = CalculationSession(data / 'native-model.json', output / 'cache', boundary_bundle=data)
assert (session._options().digits, session._options().guard_digits, session._options().series_order) == (20, 20, 16)
def no_generation(**kwargs):
    raise AssertionError('This supplied-boundary acceptance must not regenerate boundaries')
session.generate_boundaries = no_generation
report = {
    'scope': 'native shared-host release cdylib; supplied boundaries; full notebook controller stages; one CPU',
    'runtime': runtime, 'runner': file_attestation(__file__),
    'extension_build': json.loads((output.parent / 'native-development-extension.json').read_text()),
    'stage_seconds': {}, 'reference_inputs': {},
    'physical_settings': {'digits':20, 'guard_digits':20, 'series_order':16, 'workers':1},
}
def run(name, label=None):
    started = perf_counter()
    session.submit(name)
    result = session.wait()
    report['stage_seconds'][label or name] = perf_counter() - started
    print(name, report['stage_seconds'][label or name], flush=True)
    return result

try:
    assert len(session.seeds) == len(session.cache) == 0
    seeds = run('supplied_boundaries')
    assert len(seeds) == 16 and all(r.verified_digits == 40 for r in seeds.values())
    results = run('transport')
    observables = run('amplitude')
    assert all(d is not None and d >= 20 for d in observables.verified_relative_digits.values())
    assert all(r.verified_digits >= 20 for r in results.values())
    reference, report['reference_inputs']['transport'] = load_comparison_reference(data / 'coherent-reference.json')
    count = check_transport_reference_coverage(results, reference, [c.label for _, c in session.configurations])
    assert count == 4360
    one, tolerance = Float('1', decimal_digits=100), Float('1e-20', decimal_digits=100)
    maximum = Float('0', decimal_digits=100)
    for case in reference['cases']:
        actual = results[case['label']]
        assert case['source_verified_digits_cap'] >= 20
        for row, expected_row in zip(actual.coefficients, case['reference_values'], strict=True):
            for value, expected in zip(row, expected_row, strict=True):
                expected = ComplexFloat(expected['real'], expected['imaginary'], decimal_digits=100)
                difference = abs(value-expected) / max(one, abs(expected))
                assert difference <= tolerance
                maximum = max(maximum, difference)
    report['transport_comparison'] = {'coefficients': count, 'digits': 20, 'maximum_scaled_difference': str(maximum)}
    reference, report['reference_inputs']['amplitude'] = load_comparison_reference(data / 'amplitude-validation.json')
    report['form_factors'] = compare_form_factors(session.form_factors, reference)
    report['observables'] = {}
    for name, value in observables.values.items():
        expected = Float(reference['expected_observables'][name], decimal_digits=100)
        metadata = reference['reference_accuracy'][name]
        reference_error = Float(metadata['input_absolute_error'], decimal_digits=100) + Float(metadata['rounding_absolute_error'], decimal_digits=100)
        difference = abs(value-expected)
        assert difference <= observables.absolute_errors[name] + reference_error
        report['observables'][name] = {
            'value': str(value), 'absolute_error': str(observables.absolute_errors[name]),
            'verified_relative_digits': observables.verified_relative_digits[name],
            'reference_difference': str(difference), 'reference_absolute_error': str(reference_error),
            'reference_conditional_relative_digits': metadata['conditional_relative_digits'],
        }
    evidence = boundary_evidence(session.cache)
    run('restart')
    assert boundary_evidence(session.cache) == evidence
    warm = run('transport', 'warm_transport')
    assert all(r.cache_hit and r.steps == 0 for r in warm.values())
    warm_amplitude = run('amplitude', 'warm_amplitude')
    assert warm_amplitude.values == observables.values
    assert warm_amplitude.absolute_errors == observables.absolute_errors
    assert warm_amplitude.verified_relative_digits == observables.verified_relative_digits
    verify_runtime_attestation(runtime)
    report['verified_cache_entries'] = len(evidence)
    report['references_loaded_only_after_native_success'] = True
    report['runtime_unchanged'] = True
    report['status'] = 'passed'
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
finally:
    session.close()
