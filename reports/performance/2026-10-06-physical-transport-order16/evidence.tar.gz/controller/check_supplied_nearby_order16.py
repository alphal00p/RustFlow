"""Check nearby reuse after the selected one-core notebook profile."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
from time import perf_counter

SOURCE = Path('/common/dev/symbolica-community/notebook-supplied-boundaries/examples/hep')
sys.path.insert(0, str(SOURCE))
from gg_hg_support import CalculationSession
from gg_hg_acceptance import runtime_attestation, verify_runtime_attestation, file_attestation
from symbolica import E

previous, output = map(Path, sys.argv[1:])
assert json.loads((previous / 'report.json').read_text())['status'] == 'passed'
output.mkdir()
shutil.copytree(previous / 'cache', output / 'cache')
runtime = runtime_attestation()
data = SOURCE / 'data/gg_hg'
session = CalculationSession(data / 'native-model.json', output / 'cache', boundary_bundle=data)
def no_generation(**kwargs):
    raise AssertionError('Nearby supplied-boundary acceptance must not regenerate boundaries')
session.generate_boundaries = no_generation
report = {
    'status': 'running', 'runtime': runtime, 'runner': file_attestation(__file__),
    'scope': 'Native shared-host controller, one CPU; nearby reuse from copied order16 cache',
    'physical_settings': {'digits': 20, 'guard_digits': 20, 'series_order': 16, 'workers': 1},
    'previous_report_sha256': hashlib.sha256((previous / 'report.json').read_bytes()).hexdigest(),
    'stage_seconds': {},
}
def run(name, label=None, **kwargs):
    started = perf_counter()
    session.submit(name, **kwargs)
    result = session.wait()
    report['stage_seconds'][label or name] = perf_counter() - started
    print(label or name, report['stage_seconds'][label or name], flush=True)
    return result

try:
    assert len(session.cache) == 48
    original_point = session.point[:]
    original = run('transport', 'warm_original_transport')
    assert len(original) == 16 and all(r.cache_hit and r.steps == 0 for r in original.values())
    nearby = run('transport', 'nearby_transport', nearby=True)
    assert session.point == [original_point[0] + E('1/100000'), *original_point[1:]]
    assert len(nearby) == 16
    report['cases'] = []
    for label, result in nearby.items():
        assert not result.cache_hit and result.steps > 0
        assert result.starting_coordinates == original[label].coordinates
        assert result.verified_digits >= 20
        report['cases'].append({
            'label': label, 'verified_digits': result.verified_digits,
            'input_verified_digits': result.input_verified_digits,
            'working_bits': result.working_bits, 'steps': result.steps,
            'inserted_points': result.inserted_points,
            'selected_previous_destination': True,
        })
    observables = run('amplitude', 'nearby_first_amplitude')
    assert all(d is not None and d >= 20 for d in observables.verified_relative_digits.values())
    report['observables'] = {
        label: {'value': str(value), 'absolute_error': str(observables.absolute_errors[label]),
                'verified_relative_digits': observables.verified_relative_digits[label]}
        for label, value in observables.values.items()
    }
    verify_runtime_attestation(runtime)
    report['final_cache_entries'] = len(session.cache)
    report['status'] = 'passed'
finally:
    session.close()
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
