"""Independent rational audit of a new finite-series profile, comparison only."""
import gzip
import hashlib
import json
from pathlib import Path
import sys
from fractions import Fraction


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(encoded):
    value=Fraction(encoded[0])
    bits=encoded[1]
    assert type(bits) is int and bits>=2
    assert value.denominator & (value.denominator-1)==0
    n=abs(value.numerator)
    if n:
        assert n.bit_length()-((n & -n).bit_length()-1)<=bits
    return value


def inequality(za,ea,zb,eb,relative=False):
    ar,ai=map(number,za);br,bi=map(number,zb)
    ae,be=number(ea),number(eb)
    assert ae>=0 and be>=0
    ds=(ar-br)**2+(ai-bi)**2
    bs=(ae+be)**2
    assert ds<=bs, 'difference exceeds combined admitted errors'
    ratios=[]
    errors=[]
    for r,i,e in ((ar,ai,ae),(br,bi,be)):
        scale=r*r+i*i
        if not relative: scale=max(Fraction(1),scale)
        assert scale>0
        target=scale/10**40
        assert ds<=target, 'difference exceeds requested20'
        assert e*e<=target, 'admitted error exceeds requested20'
        ratios.append(ds/target)
        errors.append(e*e/target)
    return (ds/bs if bs else Fraction(0),max(ratios),max(errors))


def boundary(a,b,original_source):
    for key in ('coordinates','root_germ','leading','last','provenance'):
        assert a[key]==b[key], key
    assert a['leading']==0 and a['last']==4
    for entry in (a,b):
        assert 20<=entry['verified_digits']<=entry['input_verified_digits']<=40
        assert len(entry['coefficients'])==len(entry['comparison_errors'])==5
    if original_source:
        assert a['input_verified_digits']==b['input_verified_digits']==40
    elif a['input_verified_digits']!=b['input_verified_digits']:
        # The only changed input cap permitted here is the derived boundary's
        # own achieved cap. Original supplied evidence may not be weakened.
        assert a['input_verified_digits']==a['verified_digits']
        assert b['input_verified_digits']==b['verified_digits']
    count=0
    maxima=[Fraction(0)]*3
    for va,ea,vb,eb in zip(a['coefficients'],a['comparison_errors'],b['coefficients'],b['comparison_errors'],strict=True):
        assert len(va)==len(vb) in (48,61)
        for za,ax,zb,bx in zip(va,ea,vb,eb,strict=True):
            maxima=[max(old,new) for old,new in zip(maxima,inequality(za,ax,zb,bx),strict=True)]
            count+=1
    return {'complex_coefficients':count,'verified_digits':[a['verified_digits'],b['verified_digits']],
            'input_caps':[a['input_verified_digits'],b['input_verified_digits']],
            'maximum_squared_ratios':dict(zip(('combined_errors','requested_difference','requested_error'),map(str,maxima),strict=True))}


def main():
    high_path,low_path,seeds_path,output=map(Path,sys.argv[1:])
    high=json.loads(high_path.read_text());low=json.loads(low_path.read_text())
    for key in ('source_digest','dependency_digest','input_blake3','origin','rustred_runtime_arities'):
        assert high[key]==low[key],key
    for key in ('digits','workers','form_factor_digits','amplitude_digits','amplitude_guard_digits'):
        assert high['settings'][key]==low['settings'][key],key
    assert high['settings']['digits']==20 and high['settings']['workers']==1
    assert high['final_cache_entries']==low['final_cache_entries']==48
    assert high['all_observables_meet_requested20'] and low['all_observables_meet_requested20']
    assert digest(seeds_path)=='984b64a1617eb111543fc3b97e1cd36c84c610cfd8a02b11e8dfa861809acee4'
    seeds=json.loads(gzip.decompress(seeds_path.read_bytes()))
    by_label={r['label']:r for r in seeds['boundaries']}
    assert len(by_label)==16
    high_cases={case['label']:case for case in high['cases']};low_cases={case['label']:case for case in low['cases']}
    assert len(high['cases'])==len(low['cases'])==len(high_cases)==len(low_cases)==16
    assert set(high_cases)==set(low_cases)==set(by_label)
    cases=[]
    for label,a in high_cases.items():
        b=low_cases[label];seed=by_label[label]
        assert seed['verified_digits']==seed['input_verified_digits']==40
        assert a['starting_coordinates']==b['starting_coordinates']
        actual={name.rsplit('::',1)[-1]:Fraction(value) for name,value in a['starting_coordinates']}
        assert actual==dict(zip(('s','t','b'),map(Fraction,seed['coordinates']),strict=True)),(label,actual)
        assert a['inserted_points']==b['inserted_points']==2
        assert len(a['new_cache_entries'])==len(b['new_cache_entries'])==2
        result=boundary(a['boundary'],b['boundary'],True)
        result['label']=label
        result['inserted']=[boundary(x,y,False) for x,y in zip(a['new_cache_entries'],b['new_cache_entries'],strict=True)]
        cases.append(result)
    assert sum(c['complex_coefficients'] for c in cases)==4360
    assert sum(x['complex_coefficients'] for c in cases for x in c['inserted'])==8720
    factors={}
    assert len(high['form_factors'])==len(low['form_factors'])==2
    assert {r['mass'] for r in high['form_factors']}=={r['mass'] for r in low['form_factors']}=={'W','Z'}
    for a in high['form_factors']:
        b=next(r for r in low['form_factors'] if r['mass']==a['mass'])
        assert a['provenance']==b['provenance']
        assert len(a['values'][0])==len(b['values'][0])==4
        assert all(d is not None and d>=20 for d in a['verified_relative_digits']+b['verified_relative_digits'])
        factors[a['mass']]=[list(map(str,inequality(za,ea,zb,eb,True))) for za,ea,zb,eb in zip(a['values'][0],a['absolute_errors'],b['values'][0],b['absolute_errors'],strict=True)]
    observables={};zero=['0',100]
    assert len(high['observables'])==len(low['observables'])==3
    assert {r['label'] for r in high['observables']}=={r['label'] for r in low['observables']}=={'electroweak_squared','interference','effective_squared'}
    for a in high['observables']:
        b=next(r for r in low['observables'] if r['label']==a['label'])
        assert a['verified_relative_digits']>=20 and b['verified_relative_digits']>=20
        observables[a['label']]={'digits':[a['verified_relative_digits'],b['verified_relative_digits']],
            'maximum_squared_ratios':list(map(str,inequality([a['value'],zero],a['absolute_error'],[b['value'],zero],b['absolute_error'],True)))}
    report={'status':'passed','arithmetic':'Exact integers and Fraction; no binary64 comparisons',
        'scope':'All4360 final and8720 inserted complex coefficients, eight form factors and three observables; each profile error and difference meets requested20 and combined error allowances.',
        'source_digest':high['source_digest'],'dependency_digest':high['dependency_digest'],'input_blake3':high['input_blake3'],'origin':high['origin'],
        'files':{str(p):digest(p) for p in (high_path,low_path,seeds_path,Path(__file__))},
        'original_seed_caps':40,'derived_input_caps':'Allowed to differ only when each equals its own achieved boundary cap; all >=20. Coordinates, root germs, epsilon ranges and provenance identical.',
        'high_settings':high['settings'],'candidate_settings':low['settings'],
        'high_seconds':sum(c['transport_seconds'] for c in high['cases']),
        'candidate_seconds':sum(c['transport_seconds'] for c in low['cases']),
        'cases':cases,'form_factors':factors,'observables':observables,
        'reference_note':high['reference_note']}
    with output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps({key:value for key,value in report.items() if key not in ('cases','form_factors','files')},indent=2))


if __name__=='__main__': main()
