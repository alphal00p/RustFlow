import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();target=root/'target';out=target/'prepared-profile-interleaved';out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(ROOT_PROFILE_REPEATS='1',OMP_NUM_THREADS='1',RAYON_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
records=[]
for repeat in range(3):
 for mode in (['baseline','prepared'] if repeat%2==0 else ['prepared','baseline']):
  source='root-profile-balanced' if mode=='baseline' else 'prepared-profile'
  binary=target/source/'native'; dest=out/f'{repeat}-{mode}';dest.mkdir(exist_ok=True)
  cmd=['taskset','-c','35',str(binary),str(dest/'values')]
  print('RUN',repeat,mode,flush=True);start=time.monotonic()
  with (dest/'stdout.json').open('w') as stdout,(dest/'stderr.log').open('w') as stderr:
   result=subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr,timeout=600)
  record={'repeat':repeat,'mode':mode,'command':cmd,'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'exit_code':result.returncode,'wall_seconds':time.monotonic()-start}
  (dest/'run.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
  (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
  print(record,flush=True)
  if result.returncode: raise SystemExit(result.returncode)
