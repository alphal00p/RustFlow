import json,statistics
from pathlib import Path
root=Path('target/prepared-profile-interleaved')
data={}
for repeat in range(3):
 for mode in ['baseline','prepared']:
  d=root/f'{repeat}-{mode}';record=json.loads((d/'run.json').read_text());assert record['exit_code']==0
  data[(repeat,mode)]=json.loads((d/'stdout.json').read_text())
for repeat in range(3):
 a=data[repeat,'baseline'];b=data[repeat,'prepared']
 assert {k:v for k,v in a.items() if k not in ['cases','fixture_parse_seconds']}=={k:v for k,v in b.items() if k not in ['cases','fixture_parse_seconds']}
cases=[]
for index in range(2):
 label=data[0,'baseline']['cases'][index]['label']; rows=[]
 for repeat in range(3):
  a=data[repeat,'baseline']['cases'][index];b=data[repeat,'prepared']['cases'][index]
  assert a['label']==b['label']==label
  assert {k:v for k,v in a.items() if k not in ['runs','setup_seconds']}=={k:v for k,v in b.items() if k not in ['runs','setup_seconds']}
  ar=a['runs'][0];br=b['runs'][0]
  assert {k:v for k,v in ar.items() if k!='seconds'}=={k:v for k,v in br.items() if k!='seconds'}
  rows.append({'baseline':ar['seconds'],'prepared':br['seconds']})
 medians={k:{'baseline_seconds':statistics.median(row['baseline'][k] for row in rows),'prepared_seconds':statistics.median(row['prepared'][k] for row in rows),'paired_speed_ratios':[row['baseline'][k]/row['prepared'][k] for row in rows]} for k in rows[0]['baseline']}
 for value in medians.values():value['median_speed_ratio']=value['baseline_seconds']/value['prepared_seconds']
 cases.append({'label':label,'all_non_timing_outputs_equal':True,'median_timings':medians,'samples':rows})
result={'scope':'Three alternating baseline/prepared frozen binary pairs on CPU35; shared cluster host, other workloads present; not statistical proof or upstream parity. Each binary evaluates both systems and retains all source/refinement/uncertainty checks.','cases':cases}
(root/'comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
