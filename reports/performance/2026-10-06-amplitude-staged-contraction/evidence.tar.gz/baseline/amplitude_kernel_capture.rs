//! Read-only profile of the existing first-use native amplitude owner path.
use serde_json::json;
use std::{
    fs,
    sync::{Arc, Mutex},
    time::Instant,
};
use symbolica_amflow::symbolica::atom::AtomCore;
use symbolica_amflow::{Error, Progress, Result, RunContext, gg_hg::amplitude::HiggsJetAmplitude};

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    let started = Instant::now();
    let model = Arc::new(
        feynkit_model::Model::from_json(include_str!("../fixtures/gg-hg/native-model.json"))
            .map_err(|e| Error::InvalidInput(e.to_string()))?,
    );
    let model_seconds = started.elapsed().as_secs_f64();
    let events = Arc::new(Mutex::new(Vec::new()));
    let receiver = events.clone();
    let started = Instant::now();
    let context = RunContext {
        progress: Some(Arc::new(move |event| {
            if let Progress::Stage { name } = event {
                let seconds = started.elapsed().as_secs_f64();
                eprintln!("STAGE {seconds:.9} {name}");
                receiver
                    .lock()
                    .unwrap()
                    .push(json!({"seconds":seconds,"stage":name}));
            }
        })),
        ..Default::default()
    };
    let kernel = HiggsJetAmplitude::new(model.clone(), &context)?;
    let kernel_seconds = started.elapsed().as_secs_f64();
    assert!(
        kernel
            .diagrams()
            .iter()
            .all(|g| std::ptr::eq(g.model(), model.as_ref()))
    );
    let expressions = kernel
        .expressions()
        .iter()
        .map(|a| a.to_canonical_string())
        .collect::<Vec<_>>();
    let encoded = serde_json::to_vec(&expressions).unwrap();
    let report = json!({"scope":"existing native first-use amplitude constructor; no source or owner edits","source_digest":env!("PORT_SOURCE_DIGEST"),"dependency_digest":env!("DEPENDENCY_SOURCE_DIGEST"),"model_seconds":model_seconds,"kernel_seconds":kernel_seconds,"events":*events.lock().unwrap(),"native_diagrams":kernel.diagrams().len(),"expression_characters":expressions.iter().map(|s|s.len()).collect::<Vec<_>>(),"expressions_blake3":blake3::hash(&encoded).to_hex().to_string()});
    fs::write(&args[1], serde_json::to_vec_pretty(&report).unwrap())?;
    if let Some(path) = args.get(2) {
        fs::write(path, serde_json::to_vec(&expressions).unwrap())?;
    }
    eprintln!("DONE kernel {kernel_seconds:.9}");
    Ok(())
}
