//! Read-only profile of the existing first-use native amplitude owner path.
use serde_json::json;
use std::collections::BTreeMap;
use std::{
    fs,
    sync::{Arc, Mutex},
    time::Instant,
};
use symbolica_amflow::gg_hg::amplitude::HiggsJetFormFactors;
use symbolica_amflow::symbolica::prelude::*;
use symbolica_amflow::{ComplexFloat, Precision};
use symbolica_amflow::{Error, Progress, Result, RunContext, gg_hg::amplitude::HiggsJetAmplitude};

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    let started = Instant::now();
    let model = Arc::new(
        feynkit_model::Model::from_json(include_str!("../fixtures/gg-hg/native-model.json"))
            .map_err(|e| Error::InvalidInput(e.to_string()))?,
    );
    let model_seconds = started.elapsed().as_secs_f64();
    let events = Arc::new(Mutex::new(Vec::new()));
    let receiver = events.clone();
    let started = Instant::now();
    let context = RunContext {
        progress: Some(Arc::new(move |event| {
            if let Progress::Stage { name } = event {
                let seconds = started.elapsed().as_secs_f64();
                eprintln!("STAGE {seconds:.9} {name}");
                receiver
                    .lock()
                    .unwrap()
                    .push(json!({"seconds":seconds,"stage":name}));
            }
        })),
        ..Default::default()
    };
    let kernel = HiggsJetAmplitude::new(model.clone(), &context)?;
    let kernel_seconds = started.elapsed().as_secs_f64();
    assert!(
        kernel
            .diagrams()
            .iter()
            .all(|g| std::ptr::eq(g.model(), model.as_ref()))
    );
    let expressions = kernel
        .expressions()
        .iter()
        .map(|a| a.to_canonical_string())
        .collect::<Vec<_>>();
    let encoded = serde_json::to_vec(&expressions).unwrap();
    let report = json!({"scope":"native first-use amplitude constructor probe; owner implementations unchanged","source_digest":env!("PORT_SOURCE_DIGEST"),"dependency_digest":env!("DEPENDENCY_SOURCE_DIGEST"),"model_seconds":model_seconds,"kernel_seconds":kernel_seconds,"events":*events.lock().unwrap(),"native_diagrams":kernel.diagrams().len(),"expression_characters":expressions.iter().map(|s|s.len()).collect::<Vec<_>>(),"expressions_blake3":blake3::hash(&encoded).to_hex().to_string()});

    let reference: Vec<String> = serde_json::from_slice(&fs::read(&args[2])?).unwrap();
    assert_eq!(reference.len(), 3);
    let mut exact_equal = Vec::new();
    for (actual, text) in kernel.expressions().iter().zip(&reference) {
        let expected = Atom::parse(text, "amplitude_kernel_check", Default::default())
            .map_err(|e| Error::InvalidInput(e.to_string()))?;
        exact_equal.push((actual - &expected).expand().is_zero());
    }
    assert_eq!(exact_equal, vec![true, true, true]);
    let input_bytes = fs::read(&args[3])?;
    let input: serde_json::Value = serde_json::from_slice(&input_bytes).unwrap();
    let number = |value: &serde_json::Value| -> Result<Float> {
        let exact = Atom::parse(
            value[0].as_str().unwrap(),
            "amplitude_kernel_check",
            Default::default(),
        )
        .map_err(|e| Error::InvalidInput(e.to_string()))?;
        let exact = Complex::<Rational>::try_from(exact.as_view())
            .map_err(|e| Error::InvalidInput(e.to_string()))?;
        assert!(exact.im.is_zero());
        let result = Precision {
            bits: value[1].as_u64().unwrap() as u32,
        }
        .rational(&exact.re)
        .re;
        assert_eq!(result.to_rational(), exact.re);
        Ok(result)
    };
    let mut values = Vec::new();
    let mut errors = Vec::new();
    for mass in ["W", "Z"] {
        let block = input["form_factors"]
            .as_array()
            .unwrap()
            .iter()
            .find(|r| r["mass"] == mass)
            .unwrap();
        for value in block["values"][0].as_array().unwrap() {
            values.push(ComplexFloat::new(number(&value[0])?, number(&value[1])?));
        }
        for error in block["absolute_errors"].as_array().unwrap() {
            errors.push(number(error)?);
        }
    }
    let factors = HiggsJetFormFactors {
        values: values.try_into().unwrap(),
        absolute_errors: errors.try_into().unwrap(),
        provenance: "unchanged native full16 guard60/order96 form factors and admitted errors"
            .into(),
    };
    let atom = |text: &str| Atom::parse(text, "UFO", Default::default()).unwrap();
    let [s, t, h] = [
        "7173070292440521/111284741846000",
        "-12058167788971/339319588980",
        "1",
    ]
    .map(atom);
    let parameters = [
        ("aEWM1", "128"),
        ("aS", "118/1000"),
        ("MZ", "(7775/14631)^(1/2)"),
        (
            "Gf",
            "𝜋*(1/128)*(7775/14631)/(2^(1/2)*(5399/13074)*((7775/14631)-(5399/13074)))",
        ),
    ]
    .into_iter()
    .map(|(k, v)| (atom(k), atom(v)))
    .collect::<BTreeMap<_, _>>();
    let start = Instant::now();
    let result = kernel.evaluate(&s, &t, &h, &factors, &parameters, 20, 40, &context)?;
    let amplitude_seconds = start.elapsed().as_secs_f64();
    let encoded = |value: &Float| json!([value.to_rational().to_string(), value.prec()]);
    let mut observables = Vec::new();
    for (label, value) in [
        ("electroweak_squared", &result.electroweak_squared),
        ("interference", &result.interference),
        ("effective_squared", &result.effective_squared),
    ] {
        assert!(value.verified_relative_digits.is_some_and(|d| d >= 20));
        observables.push(json!({"label":label,"value":encoded(&value.value),"absolute_error":encoded(&value.absolute_error),"arithmetic_change":encoded(&value.arithmetic_change),"verified_relative_digits":value.verified_relative_digits}));
    }
    let report = json!({"kernel":report,"exact_scalar_kernel_equality":exact_equal,"supplied_form_factor_document_blake3":blake3::hash(&input_bytes).to_hex().to_string(),"observables":observables,"amplitude_seconds":amplitude_seconds,"amplitude_working_bits":result.working_bits});

    fs::write(&args[1], serde_json::to_vec_pretty(&report).unwrap())?;
    eprintln!("DONE kernel {kernel_seconds:.9}");
    Ok(())
}
