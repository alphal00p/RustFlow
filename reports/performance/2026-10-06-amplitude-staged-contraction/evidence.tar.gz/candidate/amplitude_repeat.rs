use std::{fs,sync::Arc,time::Instant,collections::BTreeMap};
use symbolica_amflow::{Error,Result,RunContext,Progress};
use symbolica_amflow::symbolica::prelude::*;
use symbolica_amflow::gg_hg::amplitude::effective_form_factors;
use feynkit_generator::{GenerationOptions,Process};
use feynkit_model::Model;
use feynkit_kinematics::Kinematics;
use idenso::color::ColorSimplifier;
fn native_error(e:impl std::fmt::Display)->Error {Error::InvalidInput(e.to_string())}
fn ufo(name:&str)->Atom {Atom::var(symbol!(&format!("UFO::{name}")))}
#[allow(dead_code)]
fn baseline(model: Arc<Model>, context:&RunContext) -> Result<Atom> {
        let ff_names = ["GGGHEWWW", "GGGHEWZZ"]
            .into_iter()
            .flat_map(|tag| {
                (1..=4).flat_map(move |index| {
                    ["RE", "IM"]
                        .into_iter()
                        .map(move |component| format!("{tag}_ForFac{index}_{component}"))
                })
            })
            .collect::<Vec<_>>();
        for name in ff_names
            .iter()
            .cloned()
            .chain((1..=4).map(|i| format!("GGGH_HEFT_ForFac{i}")))
        {
            model.parameter(&name).map_err(native_error)?;
        }
        let process = Process::new(["G", "G"], ["G", "H"]).with_filters(
            vec![],
            Some(vec![
                "GGGHEWZZ".into(),
                "GGGHEWWW".into(),
                "GGGHHEFT".into(),
            ]),
            vec![],
        );
        let amplitude = process
            .generate_amplitude(
                model.clone(),
                &GenerationOptions::default()
                    .with_loop_count(0, 0)
                    .map_err(native_error)?
                    .threads(1),
                Default::default(),
            )
            .map_err(native_error)?;
        context.emit(Progress::Stage {
            name: "summing native Higgs-jet spin and color states".into(),
        })?;

        let summed = amplitude
            .squared()
            .map_err(native_error)?
            .sum_spins(
                &[0, 1, 2, 3],
                true,
                &Default::default(),
                &Default::default(),
            )
            .map_err(native_error)?
            .sum_colors(&[0, 1, 2, 3], true)
            .map_err(native_error)?;
        context.emit(Progress::Stage {
            name: "contracting native Higgs-jet tensors".into(),
        })?;
        let scalar =
            idenso::tensor::SymbolicTensor::<spenso::structure::partial::PartialStructure>::infer(
                summed.expression().clone(),
            )
            .map_err(native_error)?
            .expanded(None, false)
            .map_err(native_error)?
            .simplify_algebra(&idenso::tensor::AlgebraSettings {
                contract: idenso::tensor::AlgebraContraction::Dots,
                ..idenso::tensor::AlgebraSettings::hep()
            })
            .map_err(native_error)?;
        if !scalar.is_scalar() {
            return Err(Error::Unsupported(
                "Higgs-jet state sum retains tensor indices".into(),
            ));
        }
        context.emit(Progress::Stage {
            name: "preparing kinematics-dependent Higgs-jet scalar kernels".into(),
        })?;
        let coordinates = [
            symbol!("symbolica_amflow::higgs_jet_s"),
            symbol!("symbolica_amflow::higgs_jet_t"),
            symbol!("symbolica_amflow::higgs_jet_mass_squared"),
        ];
        let [s, t, h] = coordinates.map(Atom::var);
        let u = &h - &s - &t;
        let momenta = (0..4)
            .map(|i| feynkit_graph::symbols::external_momentum().call(i))
            .collect::<Vec<_>>();
        let products = [
            [Atom::Zero, &s / 2, -&t / 2, (&s + &t) / 2],
            [&s / 2, Atom::Zero, -&u / 2, (&s + &u) / 2],
            [-&t / 2, -&u / 2, Atom::Zero, (&s - &h) / 2],
            [(&s + &t) / 2, (&s + &u) / 2, (&s - &h) / 2, h.clone()],
        ];
        let mut kinematics = Kinematics::new();
        for (i, row) in products.iter().enumerate() {
            for (j, product) in row.iter().enumerate().skip(i) {
                kinematics = kinematics
                    .with_scalar_product(&momenta[i], &momenta[j], product.clone())
                    .map_err(native_error)?;
            }
        }
        let scalar = kinematics.apply(&scalar.into_expression().to_cof_dimension_invariants());
        let expression = model.expand_couplings(&scalar);
        let mut expression = model.expand_parameters(&expression).map_err(native_error)?;
        context.cancellation.check()?;
        let wildcard = symbol!("symbolica_amflow::higgs_jet_conjugate_");
        expression = expression
            .replace(function!(symbol!("spenso::conj"), wildcard))
            .with(Atom::var(wildcard).conj());
        let variables = ff_names.iter().map(|name| ufo(name)).collect::<Vec<_>>();
        for variable in variables
            .iter()
            .cloned()
            .chain((1..=4).map(|i| ufo(&format!("GGGH_HEFT_ForFac{i}"))))
        {
            expression = expression.replace(variable.conj()).with(variable);
        }
        let marker = Atom::var(symbol!("symbolica_amflow::higgs_jet_effective_marker"));
        let replacements = effective_form_factors(&s, &t, &h)
            .into_iter()
            .enumerate()
            .map(|(i, value)| (ufo(&format!("GGGH_HEFT_ForFac{}", i + 1)), &marker * value))
            .collect();
        let expression = symbolica_amflow::family::substitute(&expression, &replacements).expand();

 Ok(expression)
}

fn late(model: Arc<Model>, context:&RunContext) -> Result<Atom> {
        let ff_names = ["GGGHEWWW", "GGGHEWZZ"]
            .into_iter()
            .flat_map(|tag| {
                (1..=4).flat_map(move |index| {
                    ["RE", "IM"]
                        .into_iter()
                        .map(move |component| format!("{tag}_ForFac{index}_{component}"))
                })
            })
            .collect::<Vec<_>>();
        for name in ff_names
            .iter()
            .cloned()
            .chain((1..=4).map(|i| format!("GGGH_HEFT_ForFac{i}")))
        {
            model.parameter(&name).map_err(native_error)?;
        }
        let process = Process::new(["G", "G"], ["G", "H"]).with_filters(
            vec![],
            Some(vec![
                "GGGHEWZZ".into(),
                "GGGHEWWW".into(),
                "GGGHHEFT".into(),
            ]),
            vec![],
        );
        let amplitude = process
            .generate_amplitude(
                model.clone(),
                &GenerationOptions::default()
                    .with_loop_count(0, 0)
                    .map_err(native_error)?
                    .threads(1),
                Default::default(),
            )
            .map_err(native_error)?;
        context.emit(Progress::Stage {
            name: "summing native Higgs-jet spin and color states".into(),
        })?;

        let summed = amplitude
            .squared()
            .map_err(native_error)?
            .sum_spins(
                &[0, 1, 2, 3],
                true,
                &Default::default(),
                &Default::default(),
            )
            .map_err(native_error)?
            .sum_colors(&[0, 1, 2, 3], true)
            .map_err(native_error)?;
        context.emit(Progress::Stage {
            name: "contracting native Higgs-jet tensors".into(),
        })?;
        let scalar =
            idenso::tensor::SymbolicTensor::<spenso::structure::partial::PartialStructure>::infer(
                summed.expression().clone(),
            )
            .map_err(native_error)?
            .simplify_algebra(&idenso::tensor::AlgebraSettings {
                contract: idenso::tensor::AlgebraContraction::Dots,
                ..idenso::tensor::AlgebraSettings::hep()
            })
            .map(|value| {eprintln!("first reduction {:?}, contracted {}, scalar {}",value.reduction_status(),value.contraction_complete(),value.is_scalar()); value})
            .map_err(native_error)?
            .expanded(None, false)
            .map_err(native_error)?
            .simplify_algebra(&idenso::tensor::AlgebraSettings {
                contract: idenso::tensor::AlgebraContraction::Dots,
                ..idenso::tensor::AlgebraSettings::hep()
            })
            .map(|value| {eprintln!("second reduction {:?}, contracted {}, scalar {}",value.reduction_status(),value.contraction_complete(),value.is_scalar()); value})
            .map_err(native_error)?;
        if !scalar.is_scalar() {
            return Err(Error::Unsupported(
                "Higgs-jet state sum retains tensor indices".into(),
            ));
        }
        context.emit(Progress::Stage {
            name: "preparing kinematics-dependent Higgs-jet scalar kernels".into(),
        })?;
        let coordinates = [
            symbol!("symbolica_amflow::higgs_jet_s"),
            symbol!("symbolica_amflow::higgs_jet_t"),
            symbol!("symbolica_amflow::higgs_jet_mass_squared"),
        ];
        let [s, t, h] = coordinates.map(Atom::var);
        let u = &h - &s - &t;
        let momenta = (0..4)
            .map(|i| feynkit_graph::symbols::external_momentum().call(i))
            .collect::<Vec<_>>();
        let products = [
            [Atom::Zero, &s / 2, -&t / 2, (&s + &t) / 2],
            [&s / 2, Atom::Zero, -&u / 2, (&s + &u) / 2],
            [-&t / 2, -&u / 2, Atom::Zero, (&s - &h) / 2],
            [(&s + &t) / 2, (&s + &u) / 2, (&s - &h) / 2, h.clone()],
        ];
        let mut kinematics = Kinematics::new();
        for (i, row) in products.iter().enumerate() {
            for (j, product) in row.iter().enumerate().skip(i) {
                kinematics = kinematics
                    .with_scalar_product(&momenta[i], &momenta[j], product.clone())
                    .map_err(native_error)?;
            }
        }
        let scalar = kinematics.apply(&scalar.into_expression().to_cof_dimension_invariants());
        let expression = model.expand_couplings(&scalar);
        let mut expression = model.expand_parameters(&expression).map_err(native_error)?;
        context.cancellation.check()?;
        let wildcard = symbol!("symbolica_amflow::higgs_jet_conjugate_");
        expression = expression
            .replace(function!(symbol!("spenso::conj"), wildcard))
            .with(Atom::var(wildcard).conj());
        let variables = ff_names.iter().map(|name| ufo(name)).collect::<Vec<_>>();
        for variable in variables
            .iter()
            .cloned()
            .chain((1..=4).map(|i| ufo(&format!("GGGH_HEFT_ForFac{i}"))))
        {
            expression = expression.replace(variable.conj()).with(variable);
        }
        let marker = Atom::var(symbol!("symbolica_amflow::higgs_jet_effective_marker"));
        let replacements = effective_form_factors(&s, &t, &h)
            .into_iter()
            .enumerate()
            .map(|(i, value)| (ufo(&format!("GGGH_HEFT_ForFac{}", i + 1)), &marker * value))
            .collect();
        let expression = symbolica_amflow::family::substitute(&expression, &replacements).expand();

 Ok(expression)
}
fn snapshot(label:&str,a:&Atom,path:&str)->serde_json::Value {
 let text=a.to_canonical_string();
 fs::write(format!("{path}/{label}-intermediate.txt"),&text).unwrap();
 let mut heads=BTreeMap::<String,usize>::new(); let mut powers=0usize;
 a.visitor(&mut |v| {match v {AtomView::Fun(f)=>{*heads.entry(f.get_symbol().to_string()).or_default()+=1;},AtomView::Pow(_)=>powers+=1,_=>{}} true});
 serde_json::json!({"characters":text.len(),"blake3":blake3::hash(text.as_bytes()).to_hex().to_string(),"symbols":a.get_all_symbols(false).len(),"powers":powers,"function_heads":heads})
}
fn main()->Result<()> {
 let args=std::env::args().collect::<Vec<_>>();
 let model=Arc::new(Model::from_json(include_str!("../fixtures/gg-hg/native-model.json")).map_err(native_error)?);
 let mut records=Vec::new(); let mut expressions=Vec::new();
 for (label,fun) in [("repeat",late as fn(Arc<Model>,&RunContext)->Result<Atom>)] {
  let now=Instant::now(); let context=RunContext{progress:Some(Arc::new(move |event| {if let Progress::Stage{name}=event{eprintln!("{label} {:.9} {name}",now.elapsed().as_secs_f64())}})),..Default::default()};
  let value=fun(model.clone(),&context)?; let seconds=now.elapsed().as_secs_f64();
  let record=serde_json::json!({"profile":label,"seconds":seconds,"shape":snapshot(label,&value,&args[1])});
  eprintln!("{record}"); records.push(record); expressions.push(value);
 }
 let expected=Atom::parse(&fs::read_to_string(format!("{}/baseline-intermediate.txt",args[1]))?,"diagnostic",Default::default()).map_err(native_error)?;
 let exact=(&expected-&expressions[0]).expand().is_zero();
 let report=serde_json::json!({"profiles":records,"exact_expanded_intermediate_equal":exact});
 fs::write(format!("{}/repeat-intermediates.json",args[1]),serde_json::to_vec_pretty(&report).unwrap())?;
 eprintln!("exact intermediate equality {exact}"); Ok(())
}
