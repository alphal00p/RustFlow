import json
import sys
from fractions import Fraction
from pathlib import Path

baseline=json.loads(Path(sys.argv[1]).read_text())
candidate=json.loads(Path(sys.argv[2]).read_text())
assert candidate['exact_scalar_kernel_equality']==[True,True,True]
comparisons=[]
for a,b in zip(baseline['observables'],candidate['observables'],strict=True):
    assert a['label']==b['label']
    assert a['verified_relative_digits']>=20 and b['verified_relative_digits']>=20
    x,y=Fraction(a['value'][0]),Fraction(b['value'][0])
    ax,ay=Fraction(a['absolute_error'][0]),Fraction(b['absolute_error'][0])
    assert ax>=0 and ay>=0
    assert abs(x-y)<=ax+ay
    assert ax<=abs(x)/10**20 and ay<=abs(y)/10**20
    assert abs(x-y)<=min(abs(x),abs(y))/10**20
    comparisons.append({
        'label':a['label'],
        'value_and_precision_identical':a['value']==b['value'],
        'error_and_precision_identical':a['absolute_error']==b['absolute_error'],
        'arithmetic_change_and_precision_identical':a['arithmetic_change']==b['arithmetic_change'],
        'baseline_verified_relative_digits':a['verified_relative_digits'],
        'candidate_verified_relative_digits':b['verified_relative_digits'],
        'difference_exact':str(abs(x-y)),
        'error_difference_exact':str(ay-ax),
        'within_combined_admitted_errors':True,
        'both_admitted_errors_and_difference_meet_requested20':True,
    })
report={'scalar_kernels_exactly_equal':True,'observables':comparisons,'candidate_kernel_seconds':candidate['kernel']['kernel_seconds'],'candidate_amplitude_seconds':candidate['amplitude_seconds']}
Path(sys.argv[3]).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
