//! Temporary wall-clock profiling only; no numerical behavior changes.
use std::time::Instant;
pub(crate) struct Span {
    name: &'static str,
    bits: u32,
    order: usize,
    start: Instant,
}
impl Span {
    pub(crate) fn new(name: &'static str, bits: u32, order: usize) -> Self {
        Self {
            name,
            bits,
            order,
            start: Instant::now(),
        }
    }
}
impl Drop for Span {
    fn drop(&mut self) {
        eprintln!(
            "PROFILE|{}|{}|{}|{}",
            self.name,
            self.bits,
            self.order,
            self.start.elapsed().as_nanos()
        );
    }
}
pub(crate) fn lap(start: &mut Instant, name: &str, bits: u32, order: usize) {
    eprintln!(
        "PROFILE|{}|{}|{}|{}",
        name,
        bits,
        order,
        start.elapsed().as_nanos()
    );
    *start = Instant::now();
}
