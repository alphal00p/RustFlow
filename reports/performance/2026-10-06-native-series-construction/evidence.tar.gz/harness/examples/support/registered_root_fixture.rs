#![allow(unused_imports, dead_code)]
//! Offline loader for independently serialized mixed QCD–EW Higgs-plus-jet data.
use serde_json::Value;
use std::collections::BTreeMap;
use std::sync::atomic::{AtomicU64, Ordering};
static TEMPORARY_SEQUENCE: AtomicU64 = AtomicU64::new(0);
use symbolica::prelude::*;
use symbolica_amflow::algebraic::{CanonicalAlgebraicSystem, SquareRoot};
use symbolica_amflow::physical_transport::RustFlow;
use symbolica_amflow::transport_cache::{
    BoundaryAccuracy, CachedBoundary, CachedPoint, EpsilonRange, PointKind, RootGerm, RootSheet,
    RustFlowCache, ScaledDistance,
};
use symbolica_amflow::{
    ComplexFloat, Error, FlowOptions, Precision, Prescription, Result, RunContext,
};

pub fn fixture() -> Value {
    serde_json::from_str(include_str!("../../fixtures/gg-hg/full-systems.json")).unwrap()
}
pub fn atom(s: &str) -> Result<Atom> {
    Atom::parse(s, "gg_hg_offline", Default::default())
        .map_err(|e| Error::InvalidInput(e.to_string()))
}
pub fn symbol(s: &str) -> Symbol {
    if let AtomView::Var(v) = atom(s).unwrap().as_view() {
        v.get_symbol()
    } else {
        panic!("fixture identifier must be a symbol")
    }
}
pub fn numbers(p: Precision, x: &Value) -> Result<Vec<Vec<ComplexFloat>>> {
    x.as_array()
        .unwrap()
        .iter()
        .map(|row| {
            row.as_array()
                .unwrap()
                .iter()
                .map(|z| {
                    p.parse(
                        z["real"].as_str().unwrap(),
                        z["imaginary"].as_str().unwrap(),
                    )
                })
                .collect()
        })
        .collect()
}
pub fn coordinates(f: &Value, name: &str) -> Result<BTreeMap<Symbol, Atom>> {
    ["s", "t", "b"]
        .into_iter()
        .zip(f[name].as_array().unwrap())
        .map(|(s, a)| Ok((symbol(s), atom(a.as_str().unwrap())?)))
        .collect()
}
pub fn system(f: &Value) -> Result<CanonicalAlgebraicSystem> {
    let n = f["dimension"].as_u64().unwrap() as usize;
    let letters = f["letters"]
        .as_array()
        .unwrap()
        .iter()
        .map(|a| atom(a.as_str().unwrap()))
        .collect::<Result<Vec<_>>>()?;
    let mut matrices = vec![vec![vec![Atom::new(); n]; n]; letters.len()];
    for row in f["matrix_entries"].as_array().unwrap() {
        let letter = row["letter"].as_u64().unwrap() as usize - 1;
        for e in row["entries"].as_array().unwrap() {
            matrices[letter][e[0].as_u64().unwrap() as usize - 1]
                [e[1].as_u64().unwrap() as usize - 1] = atom(e[2].as_str().unwrap())?;
        }
    }
    let roots = f["roots"]
        .as_array()
        .unwrap()
        .iter()
        .map(|r| {
            Ok(SquareRoot {
                symbol: symbol(r["name"].as_str().unwrap()),
                radicand: atom(r["radicand"].as_str().unwrap())?,
            })
        })
        .collect::<Result<Vec<_>>>()?;
    CanonicalAlgebraicSystem::new(
        symbol("eps"),
        &[symbol("s"), symbol("t"), symbol("b")],
        &letters,
        &matrices,
        roots,
    )
}
