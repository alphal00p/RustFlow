#[path = "support/registered_root_fixture.rs"]
mod fixture;
use fixture::{atom, coordinates, numbers, symbol, system};
use serde_json::{Value, json};
use std::{collections::BTreeMap, time::Instant};
use symbolica::prelude::*;
use symbolica_amflow::algebraic::RootSeed;
use symbolica_amflow::diffexp::EpsilonBoundary;
use symbolica_amflow::kinematics::KinematicPath;
use symbolica_amflow::physical_transport::RustFlow;
use symbolica_amflow::transport_cache::{
    BoundaryAccuracy, CachedBoundary, CachedPoint, EpsilonRange, PointKind, RootGerm, RootSheet,
    RustFlowCache, ScaledDistance,
};
use symbolica_amflow::{ComplexFloat, FlowOptions, Precision, Prescription, Result, RunContext};

fn encoded(values: &[Vec<ComplexFloat>]) -> Value {
    json!(
        values
            .iter()
            .map(|row| row
                .iter()
                .map(|z| json!({"real":z.re.to_string(),"imaginary":z.im.to_string()}))
                .collect::<Vec<_>>())
            .collect::<Vec<_>>()
    )
}
fn difference(p: Precision, a: &[Vec<ComplexFloat>], b: &[Vec<ComplexFloat>]) -> Float {
    assert_eq!(a.len(), b.len());
    let mut max = p.real(0);
    for (a, b) in a.iter().zip(b) {
        assert_eq!(a.len(), b.len());
        for (a, b) in a.iter().zip(b) {
            let e = p.norm(&p.sub(a, b));
            if e > max {
                max = e;
            }
        }
    }
    max
}
fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    let out = std::path::PathBuf::from(&args[1]);
    std::fs::create_dir_all(&out).unwrap();
    let clock = Instant::now();
    let data = fixture::fixture();
    let parse_seconds = clock.elapsed().as_secs_f64();
    let mut cases = Vec::new();
    for index in [1usize, 9] {
        let case = &data["cases"][index];
        let label = case["label"].as_str().unwrap();
        assert!(label == "W-Planar_EW1-2" || label == "W-NP_EW1-2");
        let f = data["systems"]
            .as_array()
            .unwrap()
            .iter()
            .find(|v| v["family"] == case["family"])
            .unwrap();
        let n = f["dimension"].as_u64().unwrap() as usize;
        eprintln!("SETUP {label}");
        let clock = Instant::now();
        let canonical = system(f)?;
        let system_seconds = clock.elapsed().as_secs_f64();
        let basis = (1..=n)
            .map(|i| atom(&format!("bench_I{i}")))
            .collect::<Result<Vec<_>>>()?;
        let clock = Instant::now();
        let flow = RustFlow::new_canonical(
            canonical,
            &basis,
            &Atom::one(),
            Prescription::PlusI0,
            "Matched original W nearby regular chart; fixed physical root germ",
        )?;
        let identity_seconds = clock.elapsed().as_secs_f64();
        let germ = RootGerm {
            sheets: f["roots"]
                .as_array()
                .unwrap()
                .iter()
                .zip(case["source_root_germs"].as_array().unwrap())
                .map(|(r, g)| {
                    (
                        symbol(r["name"].as_str().unwrap()),
                        match g.as_str().unwrap() {
                            "principal" => RootSheet::Principal,
                            "opposite_principal" => RootSheet::Opposite,
                            _ => panic!("invalid germ"),
                        },
                    )
                })
                .collect(),
        };
        let seeds = germ
            .sheets
            .iter()
            .map(|(&s, g)| {
                (
                    s,
                    match g {
                        RootSheet::Principal => RootSeed::Principal,
                        RootSheet::Opposite => RootSeed::Opposite,
                    },
                )
            })
            .collect::<BTreeMap<_, _>>();
        let start = coordinates(case, "start")?;
        let destination = coordinates(case, "destination")?;
        let second = destination
            .iter()
            .map(|(&s, a)| (s, a * Atom::num(2) - &start[&s]))
            .collect::<BTreeMap<_, _>>();
        let parameter = symbol("benchmark_x");
        let x = Atom::var(parameter);
        let path = KinematicPath {
            parameter,
            coordinates: start
                .iter()
                .map(|(&s, a)| (s, a + &x * (&destination[&s] - a)))
                .collect(),
        };
        let p = Precision::decimal(60)?;
        let source_p = Precision::decimal(140)?;
        let range = EpsilonRange::new(0, 4)?;
        let clock = Instant::now();
        let source = CachedBoundary {
            identity: flow.identity().clone(),
            point: CachedPoint::Exact(start.clone()).with_root_germ(germ.clone())?,
            kind: PointKind::Physical,
            range,
            coefficients: numbers(source_p, &case["source_values"])?,
            accuracy: BoundaryAccuracy::supplied(
                24,
                source_p.bits,
                case["source_errors"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|r| {
                        r.as_array()
                            .unwrap()
                            .iter()
                            .map(|v| source_p.parse(v.as_str().unwrap(), "0").map(|z| z.re))
                            .collect()
                    })
                    .collect::<Result<Vec<_>>>()?,
                "Unchanged fixture inherited original delta plus serialization reserve; cap24",
            )?,
        };
        let source_seconds = clock.elapsed().as_secs_f64();
        let boundary = EpsilonBoundary {
            point: p.zero(),
            leading: 0,
            coefficients: numbers(p, &case["source_values"])?,
        };
        let reference = numbers(source_p, &case["reference_values"])?;
        let clock = Instant::now();
        let pulled = flow.system().pullback(&path, 4)?;
        let pullback_seconds = clock.elapsed().as_secs_f64();
        let clock = Instant::now();
        let compiled = pulled.compile(p)?;
        let compile_seconds = clock.elapsed().as_secs_f64();
        let options = FlowOptions {
            digits: 20,
            guard_digits: 40,
            series_order: 64,
            ..Default::default()
        };
        let policy = ScaledDistance {
            scales: BTreeMap::new(),
            admissible: |_: &CachedBoundary, _: &CachedPoint| Ok(true),
        };
        let context = RunContext::default();
        let mut runs = Vec::new();
        for repeat in 0..std::env::var("ROOT_PROFILE_REPEATS")
            .ok()
            .and_then(|x| x.parse().ok())
            .unwrap_or(3)
        {
            eprintln!("RUN {label} {repeat}");
            eprintln!("STAGE {label} {repeat} fixed");
            let clock = Instant::now();
            let fixed =
                compiled.transport(&boundary, &[p.i(1)], &seeds, &options, &context, false)?;
            let fixed_seconds = clock.elapsed().as_secs_f64();
            assert!(
                difference(source_p, &fixed.solution.coefficients, &reference)
                    < source_p.tolerance(24)
            );
            let mut bank = RustFlowCache::default();
            let clock = Instant::now();
            bank.insert(source.clone())?;
            let insert_source_seconds = clock.elapsed().as_secs_f64();
            eprintln!("STAGE {label} {repeat} checked");
            let clock = Instant::now();
            let checked = flow.evaluate_to(
                &mut bank,
                &destination,
                Some(&germ),
                range,
                &options,
                &context,
                &policy,
            )?;
            let checked_seconds = clock.elapsed().as_secs_f64();
            assert!(checked.boundary.accuracy.verified_digits() >= 20);
            assert!(checked.boundary.accuracy.verified_digits() <= 24);
            assert!(
                difference(source_p, &checked.boundary.coefficients, &reference)
                    < source_p.tolerance(24)
            );
            assert!(
                difference(
                    source_p,
                    &checked.boundary.coefficients,
                    &fixed.solution.coefficients
                ) < source_p.tolerance(24)
            );
            let mut insert_bank = RustFlowCache::default();
            insert_bank.insert(source.clone())?;
            let clock = Instant::now();
            insert_bank.insert(checked.boundary.clone())?;
            let insert_endpoint_seconds = clock.elapsed().as_secs_f64();
            let file = out.join(format!("bank-{label}-{repeat}"));
            let clock = Instant::now();
            bank.save(&file)?;
            let save_seconds = clock.elapsed().as_secs_f64();
            let clock = Instant::now();
            let mut restored = RustFlowCache::load(&file)?;
            let load_seconds = clock.elapsed().as_secs_f64();
            let clock = Instant::now();
            let hit = flow.evaluate_to(
                &mut restored,
                &destination,
                Some(&germ),
                range,
                &options,
                &context,
                &policy,
            )?;
            let hit_seconds = clock.elapsed().as_secs_f64();
            assert!(hit.transport.is_none());
            assert_eq!(hit.inserted_points, 0);
            assert_eq!(hit.boundary.coefficients, checked.boundary.coefficients);
            eprintln!("STAGE {label} {repeat} nearby");
            let clock = Instant::now();
            let nearby = flow.evaluate_to(
                &mut restored,
                &second,
                Some(&germ),
                range,
                &options,
                &context,
                &policy,
            )?;
            let nearby_seconds = clock.elapsed().as_secs_f64();
            assert_eq!(
                nearby.starting_point.rounded_coordinates_as_exact()?,
                destination
            );
            assert_eq!(nearby.starting_point.root_germ(), Some(&germ));
            assert!(nearby.boundary.accuracy.verified_digits() >= 20);
            eprintln!("STAGE {label} {repeat} direct_second");
            let clock = Instant::now();
            let direct_second =
                compiled.transport(&boundary, &[p.i(2)], &seeds, &options, &context, false)?;
            let direct_second_seconds = clock.elapsed().as_secs_f64();
            assert!(
                difference(
                    source_p,
                    &nearby.boundary.coefficients,
                    &direct_second.solution.coefficients
                ) < source_p.tolerance(24)
            );
            let diagnostic = |v: &symbolica_amflow::diffexp::EpsilonSolution| json!({"accepted":v.diagnostics.steps,"rejected":v.diagnostics.rejected_steps,"working_bits":v.diagnostics.working_bits,"expansion_order":v.diagnostics.expansion_order});
            runs.push(json!({"repeat":repeat,"seconds":{"fixed_integration":fixed_seconds,"source_cache_insert":insert_source_seconds,"public_checked_cold":checked_seconds,"standalone_endpoint_cache_insert":insert_endpoint_seconds,"save":save_seconds,"load":load_seconds,"exact_hit":hit_seconds,"nearby_reuse":nearby_seconds,"independent_direct_second_validation":direct_second_seconds},"fixed_diagnostics":diagnostic(&fixed.solution),"checked_diagnostics":diagnostic(checked.transport.as_ref().unwrap()),"nearby_diagnostics":diagnostic(nearby.transport.as_ref().unwrap()),"checked_inserted_points":checked.inserted_points,"nearby_inserted_points":nearby.inserted_points,"checked_verified_digits":checked.boundary.accuracy.verified_digits(),"nearby_verified_digits":nearby.boundary.accuracy.verified_digits(),"fixed_values":encoded(&fixed.solution.coefficients),"checked_values":encoded(&checked.boundary.coefficients),"nearby_values":encoded(&nearby.boundary.coefficients),"direct_second_values":encoded(&direct_second.solution.coefficients),"checked_errors":checked.boundary.accuracy.comparison_errors().iter().map(|r|r.iter().map(ToString::to_string).collect::<Vec<_>>()).collect::<Vec<_>>(),"nearby_errors":nearby.boundary.accuracy.comparison_errors().iter().map(|r|r.iter().map(ToString::to_string).collect::<Vec<_>>()).collect::<Vec<_>>() }));
        }
        cases.push(json!({"label":label,"dimension":n,"source":case["start"],"destination":case["destination"],"second_destination":second.iter().map(|(s,a)|(Atom::var(*s).to_string(),a.to_string())).collect::<BTreeMap<_,_>>(),"root_germs":case["source_root_germs"],"setup_seconds":{"canonical_system":system_seconds,"identity":identity_seconds,"source_parse":source_seconds,"exact_pullback":pullback_seconds,"fixed_compile":compile_seconds},"runs":runs}));
        std::fs::write(
            out.join("partial.json"),
            serde_json::to_vec_pretty(&cases).unwrap(),
        )
        .unwrap();
    }
    println!(
        "{}",
        json!({"status":"passed","fixture_parse_seconds":parse_seconds,"settings":{"requested_digits":20,"fixed_working_digits":60,"public_guard_digits":40,"series_order":64,"source_verified_cap":24,"source_working_digits":140,"repeats":3,"cpu":35},"scope":"Fixed transport has no independent accuracy certification; public calls include refinement, source-uncertainty propagation and progressive cache insertion. Direct-second timings are validation only. Original comparison is separate; no overall speed ratio.","cases":cases})
    );
    Ok(())
}
