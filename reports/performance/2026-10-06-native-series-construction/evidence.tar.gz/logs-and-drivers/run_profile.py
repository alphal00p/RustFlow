import json,os,subprocess,time,hashlib,sys
from pathlib import Path
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,ROOT_PROFILE_REPEATS="1",OMP_NUM_THREADS="1",RAYON_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1")
perf="/nix/store/wizn21b9virxqcnm4n89b09pgqkaxfn3-perf-linux-7.2.5/bin/perf"
exe=Path("target/release/examples/registered_root_profile").resolve()
cmd=[perf,"record","-F","499","-e","cycles:u","-g","--call-graph","dwarf,32768","-o",str(out/"perf.data"),"--","taskset","-c","35",str(exe),str(out/"values")]
start=time.monotonic()
with (out/"stdout.json").open("w") as stdout,(out/"stderr.log").open("w") as stderr:
 r=subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr,timeout=600)
record={"command":cmd,"exit_code":r.returncode,"wall_seconds":time.monotonic()-start,"binary_sha256":hashlib.sha256(exe.read_bytes()).hexdigest(),"scope":"instrumented phase diagnostics with CPU sampling; not uninstrumented timing measurement"}
(out/"run.json").write_text(json.dumps(record,indent=2)+"\n")
raise SystemExit(r.returncode)
