from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
root=Path.cwd();target=root/'target';stage=target/'profile-evidence-stage';report=root/'reports/performance/2026-10-06-native-series-construction';report.mkdir(parents=True,exist_ok=True)
assert 'test result: ok. 1 passed;' in (target/'balanced-full-gg-hg.log').read_text()
for item in json.loads((stage/'source-manifest.json').read_text()):
 assert hashlib.file_digest((root/item['path']).open('rb'),'sha256').hexdigest()==item['sha256'],item['path']
for name in ['balanced-series-tests.log','balanced-integration-tests.log','balanced-integration-summary.json','balanced-full-gg-hg.log','balanced-clippy.log','balanced-python-clippy.log','balanced-fmt.log','balanced-diff-check.log','profile-build.log','profile-build2.log','balanced-profile-build.log','balanced-series-build.log','series-builder-build.log','series-builder-build2.log','series-builder-naive.rs','series-builder-naive-results.json','series-builder-zero-filtered-results.json','series-builder-zero-filtered-results.log','package_balanced_evidence.py','run_profile.py','run_profile_interleaved.py','compare_profile_interleaved.py','root-profile-interleaved-driver.log']:
 p=target/name
 if p.exists():dest=stage/'logs-and-drivers'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
shutil.copytree(target/'profile-harness-source',stage/'harness',dirs_exist_ok=True)
for name in ['root-profile-instrumented','root-profile-uninstrumented','root-profile-balanced','root-profile-interleaved']:
 for p in (target/name).rglob('*'):
  if p.is_file() and p.name not in ['native','perf.data'] and 'values' not in p.relative_to(target/name).parts:
   dest=stage/'measurements'/name/p.relative_to(target/name);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
validation=json.loads((target/'balanced-integration-summary.json').read_text())
batched=json.loads((target/'root-profile-balanced/comparison.json').read_text());alternating=json.loads((target/'root-profile-interleaved/comparison.json').read_text())
report_data={
 'scope':'Native balanced finite Series construction only; fresh supplied-boundary physical gg→hg transports, existing reference inputs and original source uncertainty. No automatic boundary-generation/amplitude timing or upstream performance parity claim.',
 'compiler':'rustc 1.97.1 (8bab26f4f 2026-07-14), built from source tarball','base_commit':'7e01651d1c50010ab9b140829db8835c9f9f5c09','changed_numerical_source':{'path':'src/fixed_series.rs','sha256':hashlib.file_digest((root/'src/fixed_series.rs').open('rb'),'sha256').hexdigest()},
 'native_port_source_digest':'42287297a86b8356096223fc74234cd87c98b14104022fb4227900cac03d43fd',
 'native_dependency_source_digest':'67c600c99822108adc326b5638d79629f3797a7a514640e016886f7766cf1c7e',
 'rustred_source_digest':'90d46f89e952516cf121332a603f2fedea899f221ade3bdcf94e2313f7b23232',
 'symbolica':{'remote':'https://github.com/symbolica-dev/symbolica','branch':'community','commit':'c3408e4ba1d3bdd4ea55678fad50e27009be13d4','local_changes_required':False},
 'fixture':{'path':'fixtures/gg-hg/full-systems.json','sha256':hashlib.file_digest((root/'fixtures/gg-hg/full-systems.json').open('rb'),'sha256').hexdigest()},
 'projection_fixture':{'path':'fixtures/gg-hg/projections.json','sha256':hashlib.file_digest((root/'fixtures/gg-hg/projections.json').open('rb'),'sha256').hexdigest()},
 'validation':{'focused_unit_tests':3,'integration':validation,'explicit_full_gg_hg_test':{'passed':1,'reference_coefficients':4360,'precanonical_projection_rows':4376,'form_factor_relative_digits':{f'{mass} F{index}':int(digits) for mass,index,digits in re.findall(r'([WZ]) F([1-4]): (\d+) relative digits',(target/'balanced-full-gg-hg.log').read_text())},'configurations':16,'independent_precision_order_profiles':True,'existing_coherent_projections_checked':True,'uniform_20_significant_digit_observable_claim':False},'native_all_target_strict_clippy':True,'python_stubgen_all_target_strict_clippy':True,'format_and_diff_checks':True},
 'batched_comparison':batched,'alternating_comparison':alternating,
 'timing_limitations':['Shared cluster host, not exclusive CPUs or controlled thermal/load state.','Processes pinned CPU35; concurrent compiler/tests on other pinned CPUs.','Retain raw variation and initial marginal nonplanar checked regression; alternating measurements are characterization, not statistical proof.','Builder-only speed ratios do not imply complete-transport speed ratios.','Instrumented phases overlap; do not sum enclosing and child timers.','Perf symbols report28408samples with12lost samples; diagnostic only.'],
 'numerical_evidence':{'requested_decimal_digits':20,'supplied_input_accuracy_cap':24,'observed_verified_digits':{'first_destination':21,'nearby_destination':20},'selected_profile':{'working_bits':282,'series_order':96,'accepted_steps':1,'rejected_steps':0},'all_non_timing_outputs_equal_between_baseline_and_candidate':True},
 'next_step':'Separately benchmark immutable exact registered-root preparation shared across precision profiles, while numerical compile(p) remains fresh.'}
(stage/'report-metadata.json').write_text(json.dumps(report_data,indent=2)+'\n')
(stage/'README.txt').write_text('The baseline helper is from base7e01651. The archived builder probe expects that baseline src/fixed_series.rs; reproduce it on the baseline worktree. The full registered_root_profile harness is identical for both binaries. Candidate source, raw JSON, logs, temporary instrumentation and failed sparse-builder experiment are preserved. Large executables/perf.data and redundant cache binaries are excluded; checksums are recorded.\n')
archive=report/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(stage.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(stage)))
report_data['evidence_archive']={'path':'evidence.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()}
(report/'report.json').write_text(json.dumps(report_data,indent=2)+'\n')
print(json.dumps(report_data['evidence_archive'],indent=2))
