#![allow(dead_code)]
#[path = "../src/fixed_series.rs"] mod fixed_series;
pub use symbolica_amflow::{ComplexFloat, Error, Precision, Result};
use fixed_series::{FixedComplexRing,NumericSeries};
use symbolica::prelude::*;
use symbolica::poly::series::Series;
use std::{sync::Arc,time::Instant};
fn balanced(p:Precision,x:Symbol,values:&[ComplexFloat])->Result<NumericSeries>{
    if values.is_empty() || values.len()>10001 || p.bits<2 {return Err(Error::InvalidInput("series dimensions".into()));}
    if values.iter().any(|v|!p.finite(v)){return Err(Error::Numerical("nonfinite series input".into()));}
    let prototype=Series::new(&FixedComplexRing::new(p),None,Arc::new(x.into()),p.zero(),Rational::from(values.len() as i64));
    let mut level=values.iter().enumerate().map(|(i,v)|prototype.monomial(p.round(v),Rational::from(i as i64))).collect::<Vec<_>>();
    while level.len()>1 {
        let mut next=Vec::with_capacity(level.len().div_ceil(2));
        let mut terms=level.into_iter();
        while let Some(a)=terms.next(){next.push(if let Some(b)=terms.next(){a+b}else{a});}
        level=next;
    }
    Ok(prototype.zero()+level.pop().unwrap())
}
fn main()->Result<()> {
 let x=symbol!("builder_probe::x"); let high=Precision::decimal(120)?; let mut rows=Vec::new();
 for bits in [201,333] {let p=Precision{bits};
  for n in [1usize,4,7,64,96,256,512] {
   for kind in ["dense","leading_zero","zero","sparse"] {
    let values=(0..n).map(|i|{
     if kind=="zero" || (kind=="leading_zero" && i<n/2) || (kind=="sparse" && i+1<n) {return high.zero();}
     let real=high.rational(&Rational::from(((i+1) as i64,(i+3) as i64))).re;
     let imaginary=high.rational(&Rational::from((-((i+2) as i64),(i+5) as i64))).re;
     ComplexFloat::new(real,imaginary)
    }).collect::<Vec<_>>();
    let expected=fixed_series::fixed_series(p,x,&values)?;let actual=balanced(p,x,&values)?;
    assert_eq!(expected.absolute_order(),actual.absolute_order());
    assert_eq!(actual.absolute_order(),Rational::from(n as i64));
    assert_eq!(fixed_series::coefficients(&expected,n)?,fixed_series::coefficients(&actual,n)?);
    assert!(actual.coefficient(Rational::from(n as i64)).is_none());
    let mut samples=Vec::new();
    for repeat in 0..7 {for use_balanced in if repeat%2==0 {[false,true]} else {[true,false]}{
      let start=Instant::now();let value=if use_balanced {balanced(p,x,&values)?} else {fixed_series::fixed_series(p,x,&values)?};std::hint::black_box(value);
      samples.push(serde_json::json!({"balanced":use_balanced,"ns":start.elapsed().as_nanos()}));
    }}
    rows.push(serde_json::json!({"bits":bits,"n":n,"kind":kind,"samples":samples}));
   }
  }
 }
 println!("{}",serde_json::json!({"cases":rows,"scope":"builder-only experiment with native Series additions; exact coefficient/remainder equality against existing helper"})); Ok(())
}
