//! Single-core checked transport from the exported native starting boundaries.
use serde_json::{Value, json};
use std::{collections::BTreeMap, fs, sync::Arc, time::Instant};
use symbolica::prelude::*;
use symbolica_amflow::gg_hg::amplitude::{
    HiggsJetAmplitude, HiggsJetFormFactors as AmplitudeFactors,
};
use symbolica_amflow::gg_hg::{HiggsJetConfiguration, HiggsJetIntegralSystem, PluginFamilyKind};
use symbolica_amflow::transport_cache::{
    BoundaryAccuracy, CachedBoundary, CachedPoint, EpsilonRange, PointKind, RootSheet,
};
use symbolica_amflow::{
    ComplexFloat, Error, FlowOptions, Precision, Result, RunContext, RustFlowCache,
};

fn number(value: &Value) -> Result<Float> {
    let bits = value[2].as_u64().unwrap() as u32;
    let expression = Atom::parse(
        format!(
            "({})/({})",
            value[0].as_str().unwrap(),
            value[1].as_str().unwrap()
        ),
        "initial_transport_profile",
        Default::default(),
    )
    .map_err(|error| Error::InvalidInput(error.to_string()))?;
    let rational = Complex::<Rational>::try_from(expression.as_view())
        .map_err(|error| Error::InvalidInput(error.to_string()))?;
    assert!(rational.im.is_zero());
    let result = Precision { bits }.rational(&rational.re).re;
    assert_eq!(result.to_rational(), rational.re);
    Ok(result)
}

fn encoded_number(value: &Float) -> Value {
    json!([value.to_rational().to_string(), value.prec()])
}

fn encoded_values(values: &[Vec<ComplexFloat>]) -> Value {
    json!(
        values
            .iter()
            .map(|row| row
                .iter()
                .map(|value| { json!([encoded_number(&value.re), encoded_number(&value.im)]) })
                .collect::<Vec<_>>())
            .collect::<Vec<_>>()
    )
}

fn boundary_evidence(boundary: &CachedBoundary) -> Result<Value> {
    Ok(json!({
        "coordinates": boundary.point.rounded_coordinates_as_exact()?.iter()
            .map(|(symbol, value)| (Atom::var(*symbol).to_canonical_string(), value.to_canonical_string()))
            .collect::<Vec<_>>(),
        "root_germ": boundary.point.root_germ().map(|germ| germ.sheets.iter()
            .map(|(symbol, sheet)| (Atom::var(*symbol).to_canonical_string(),
                if *sheet == RootSheet::Principal { 1 } else { -1 }))
            .collect::<Vec<_>>()),
        "leading": boundary.range.leading,
        "last": boundary.range.last,
        "coefficients": encoded_values(&boundary.coefficients),
        "comparison_errors": boundary.accuracy.comparison_errors().iter()
            .map(|row| row.iter().map(encoded_number).collect::<Vec<_>>()).collect::<Vec<_>>(),
        "verified_digits": boundary.accuracy.verified_digits(),
        "input_verified_digits": boundary.accuracy.input_verified_digits(),
        "working_bits": boundary.accuracy.working_bits(),
        "provenance": boundary.accuracy.provenance(),
    }))
}

fn import_seed(
    system: &HiggsJetIntegralSystem,
    configuration: &HiggsJetConfiguration,
    document: &Value,
) -> Result<CachedBoundary> {
    let input = document["boundaries"]
        .as_array()
        .unwrap()
        .iter()
        .find(|entry| entry["label"] == configuration.label)
        .unwrap();
    assert_eq!(
        input["dimension"].as_u64().unwrap() as usize,
        configuration.family.dimension()
    );
    assert_eq!(input["leading_power"], 0);
    assert_eq!(input["verified_digits"], input["input_verified_digits"]);
    for (&coordinate, value) in system
        .basis_map()
        .coordinates
        .iter()
        .zip(input["coordinates"].as_array().unwrap())
    {
        let exact = Atom::parse(
            value.as_str().unwrap(),
            "initial_transport_profile",
            Default::default(),
        )
        .map_err(|e| Error::InvalidInput(e.to_string()))?;
        assert_eq!(exact, configuration.start[&coordinate]);
    }
    assert_eq!(
        input["root_sheets"].as_object().unwrap().len(),
        configuration.germ.sheets.len()
    );
    for (symbol, sheet) in &configuration.germ.sheets {
        let name = Atom::var(*symbol).to_canonical_string();
        let name = name.rsplit("::").next().unwrap();
        let sign = if *sheet == RootSheet::Principal {
            1
        } else {
            -1
        };
        assert_eq!(input["root_sheets"][name], sign);
    }
    let coefficients = input["coefficients"]
        .as_array()
        .unwrap()
        .iter()
        .map(|row| {
            row.as_array()
                .unwrap()
                .iter()
                .map(|z| Ok(ComplexFloat::new(number(&z[0])?, number(&z[1])?)))
                .collect::<Result<Vec<_>>>()
        })
        .collect::<Result<Vec<_>>>()?;
    let errors = input["comparison_errors"]
        .as_array()
        .unwrap()
        .iter()
        .map(|row| {
            row.as_array()
                .unwrap()
                .iter()
                .map(number)
                .collect::<Result<Vec<_>>>()
        })
        .collect::<Result<Vec<_>>>()?;
    let source = CachedBoundary {
        identity: system.transport().identity().clone(),
        point: CachedPoint::Exact(configuration.start.clone())
            .with_root_germ(configuration.germ.clone())?,
        kind: PointKind::Physical,
        range: EpsilonRange::new(0, coefficients.len() as i32 - 1)?,
        coefficients,
        accuracy: BoundaryAccuracy::supplied(
            input["verified_digits"].as_u64().unwrap() as u32,
            input["working_bits"].as_u64().unwrap() as u32,
            errors,
            &format!(
                "{}; exact supplied export from native extension {}; original identity {}",
                input["provenance"].as_str().unwrap(),
                document["origin"]["native_extension_sha256"]
                    .as_str()
                    .unwrap(),
                input["origin_identity"].as_str().unwrap()
            ),
        )?,
    };
    Ok(source)
}
fn scalar(text: &str) -> Atom {
    Atom::parse(text, "UFO", Default::default()).unwrap()
}

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    let bytes = fs::read(&args[1])?;
    let document: Value =
        serde_json::from_slice(&bytes).map_err(|e| Error::InvalidInput(e.to_string()))?;
    assert_eq!(document["schema"], "higgs-jet-supplied-boundaries-v1");
    assert_eq!(
        document["encoding"],
        "exact-integer-ratio-with-binary-precision"
    );
    assert_eq!(document["boundaries"].as_array().unwrap().len(), 16);
    let options = FlowOptions {
        digits: 20,
        guard_digits: std::env::var("INITIAL_TRANSPORT_GUARD").map_or(60, |v| v.parse().unwrap()),
        series_order: std::env::var("INITIAL_TRANSPORT_ORDER").map_or(96, |v| v.parse().unwrap()),
        workers: 1,
        ..Default::default()
    };
    let setup = Instant::now();
    let systems = [PluginFamilyKind::Planar, PluginFamilyKind::Nonplanar]
        .into_iter()
        .map(|kind| HiggsJetIntegralSystem::load(kind, "initial_transport_profile"))
        .collect::<Result<Vec<_>>>()?;
    let configurations = systems
        .iter()
        .map(|system| system.configurations("initial_transport_profile"))
        .collect::<Result<Vec<_>>>()?;
    let mut cache = RustFlowCache::default();
    for (system, configurations) in systems.iter().zip(&configurations) {
        assert_eq!(configurations.len(), 8);
        for configuration in configurations {
            cache.insert(import_seed(system, configuration, &document)?)?;
        }
    }
    assert_eq!(cache.entries().len(), 16);
    let seed_setup_seconds = setup.elapsed().as_secs_f64();
    let setup = Instant::now();
    let projector =
        symbolica_amflow::gg_hg::HiggsJetFormFactors::load("initial_transport_profile")?;
    let projector_setup_seconds = setup.elapsed().as_secs_f64();
    let setup = Instant::now();
    let model = Arc::new(
        feynkit_model::Model::from_json(include_str!("../fixtures/gg-hg/native-model.json"))
            .map_err(|e| Error::InvalidInput(e.to_string()))?,
    );
    let context = RunContext::default();
    let kernel = HiggsJetAmplitude::new(model.clone(), &context)?;
    assert!(
        kernel
            .diagrams()
            .iter()
            .all(|g| std::ptr::eq(g.model(), model.as_ref()))
    );
    let amplitude_setup_seconds = setup.elapsed().as_secs_f64();
    let mut cases = Vec::new();
    let mut boundaries = BTreeMap::new();
    for (system, configurations) in systems.iter().zip(&configurations) {
        for configuration in configurations {
            eprintln!("START {}", configuration.label);
            let before = cache.entries().len();
            let started = Instant::now();
            let result = system.evaluate(
                &mut cache,
                &configuration.destination,
                &configuration.germ,
                4,
                &options,
                &context,
            )?;
            let seconds = started.elapsed().as_secs_f64();
            let solution = result
                .transport
                .as_ref()
                .expect("initial target must require transport");
            assert!(solution.diagnostics.steps > 0);
            assert!(result.boundary.accuracy.verified_digits() >= 20);
            let segment_bytes = bincode::serde::encode_to_vec(
                solution
                    .segments
                    .iter()
                    .map(|s| {
                        (
                            &s.center,
                            &s.end,
                            &s.coefficients,
                            s.working_bits,
                            s.conditioning_digits,
                            format!("{:?}", s.coordinate),
                        )
                    })
                    .collect::<Vec<_>>(),
                bincode::config::standard(),
            )
            .map_err(|e| Error::InvalidInput(e.to_string()))?;
            cases.push(json!({
                "label":configuration.label,
                "transport_seconds":seconds,
                "starting_coordinates":result.starting_point.rounded_coordinates_as_exact()?.iter().map(|(s,v)|(Atom::var(*s).to_canonical_string(),v.to_canonical_string())).collect::<Vec<_>>(),
                "boundary":boundary_evidence(&result.boundary)?,
                "new_cache_entries":cache.entries()[before..].iter().map(boundary_evidence).collect::<Result<Vec<_>>>()?,
                "inserted_points":result.inserted_points,
                "diagnostics":format!("{:?}",solution.diagnostics),
                "segment_coefficients_blake3":blake3::hash(&segment_bytes).to_hex().to_string(),
            }));
            boundaries.insert(configuration.label.clone(), result.boundary);
            eprintln!("DONE {} {seconds}", configuration.label);
        }
    }
    let [s, t, h] = [
        "7173070292440521/111284741846000",
        "-12058167788971/339319588980",
        "1",
    ]
    .map(scalar);
    let p = Precision::decimal(100)?;
    let mut factors = Vec::new();
    let mut values = Vec::new();
    let mut errors = Vec::new();
    let mut provenance = String::from("Native canonical boundaries and physical transport; ");
    let started = Instant::now();
    for (mass, mass_squared) in [("W", "5399/13074"), ("Z", "7775/14631")] {
        let blocks = configurations
            .iter()
            .map(|configurations| {
                let mut crossing = configurations
                    .iter()
                    .filter(|c| c.mass == mass)
                    .collect::<Vec<_>>();
                crossing.sort_by_key(|c| c.permutation);
                assert_eq!(crossing.len(), 4);
                crossing
                    .iter()
                    .map(|c| boundaries[&c.label].clone())
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
        let result =
            projector.evaluate(&s, &t, &h, &scalar(mass_squared), &blocks[0], &blocks[1], p)?;
        factors.push(json!({"mass":mass,"values":encoded_values(&[result.values.to_vec()]),"absolute_errors":result.absolute_errors.iter().map(encoded_number).collect::<Vec<_>>(),"verified_relative_digits":result.verified_relative_digits,"provenance":result.provenance}));
        provenance.push_str(&result.provenance);
        provenance.push_str("; ");
        values.extend(result.values);
        errors.extend(result.absolute_errors);
    }
    let form_factor_seconds = started.elapsed().as_secs_f64();
    let factors_input = AmplitudeFactors {
        values: values.try_into().unwrap(),
        absolute_errors: errors.try_into().unwrap(),
        provenance,
    };
    let parameters = [
        ("aEWM1", "128"),
        ("aS", "118/1000"),
        ("MZ", "(7775/14631)^(1/2)"),
        (
            "Gf",
            "𝜋*(1/128)*(7775/14631)/(2^(1/2)*(5399/13074)*((7775/14631)-(5399/13074)))",
        ),
    ]
    .into_iter()
    .map(|(k, v)| (scalar(k), scalar(v)))
    .collect::<BTreeMap<_, _>>();
    let started = Instant::now();
    let result = kernel.evaluate(&s, &t, &h, &factors_input, &parameters, 20, 40, &context)?;
    let amplitude_seconds = started.elapsed().as_secs_f64();
    let reference: Value =
        serde_json::from_str(include_str!("../fixtures/gg-hg/amplitude-validation.json")).unwrap();
    let mut observables = Vec::new();
    let mut admitted = true;
    for (label, value) in [
        ("electroweak_squared", &result.electroweak_squared),
        ("interference", &result.interference),
        ("effective_squared", &result.effective_squared),
    ] {
        admitted &= value.verified_relative_digits.is_some_and(|n| n >= 20);
        let expected = p.parse(
            reference["expected_observables"][label].as_str().unwrap(),
            "0",
        )?;
        let difference = p.norm(&p.sub(
            &ComplexFloat::new(value.value.clone(), p.real(0)),
            &expected,
        ));
        observables.push(json!({"label":label,"value":encoded_number(&value.value),"absolute_error":encoded_number(&value.absolute_error),"arithmetic_change":encoded_number(&value.arithmetic_change),"verified_relative_digits":value.verified_relative_digits,"reference_relative_difference":encoded_number(&(difference/p.norm(&expected)))}));
        eprintln!(
            "OBSERVABLE {label} verified={:?}",
            value.verified_relative_digits
        );
    }
    let report = json!({
        "scope":"all16 single-core initial physical transport, shared native systems/cache/projector/amplitude kernel; supplied native40 seeds",
        "source_digest":env!("PORT_SOURCE_DIGEST"),"dependency_digest":env!("DEPENDENCY_SOURCE_DIGEST"),"rustred_runtime_arities":rustred::compiled_runtime_arities(),
        "input_blake3":blake3::hash(&bytes).to_hex().to_string(),"origin":document["origin"],
        "settings":{"digits":options.digits,"guard_digits":options.guard_digits,"series_order":options.series_order,"workers":options.workers,"form_factor_digits":100,"amplitude_digits":20,"amplitude_guard_digits":40},
        "setup_seconds":{"seed_and_systems":seed_setup_seconds,"projector":projector_setup_seconds,"native_amplitude_kernel":amplitude_setup_seconds},
        "cases":cases,"form_factors":factors,"form_factor_seconds":form_factor_seconds,"observables":observables,"amplitude_seconds":amplitude_seconds,"amplitude_working_bits":result.working_bits,"all_observables_meet_requested20":admitted,"final_cache_entries":cache.entries().len(),"reference_note":"archived EW component inputs support19 relative digits; used only for comparison, never as evaluation input",
    });
    fs::write(
        &args[2],
        serde_json::to_vec_pretty(&report).map_err(|e| Error::InvalidInput(e.to_string()))?,
    )?;
    assert!(
        admitted,
        "native amplitude did not admit20 relative digits for all3 observables"
    );
    Ok(())
}
