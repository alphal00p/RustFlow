"""Compare all saved scientific evidence, excluding only wall time and source digest."""
import copy
import json
import sys
from pathlib import Path

baseline = json.loads(Path(sys.argv[1]).read_text())
candidate = json.loads(Path(sys.argv[2]).read_text())
left, right = copy.deepcopy(baseline), copy.deepcopy(candidate)
left.pop("source_digest")
right.pop("source_digest")
for report in (left, right):
    for case in report["cases"]:
        case.pop("setup_seconds")
        case.pop("transport_seconds")
assert left == right, "scientific evidence or fixed benchmark metadata changed"
result = {
    "all_non_timing_evidence_identical": True,
    "baseline_source_digest": baseline["source_digest"],
    "candidate_source_digest": candidate["source_digest"],
    "dependency_digest": baseline["dependency_digest"],
    "input_blake3": baseline["input_blake3"],
    "cases": [
        {
            "label": a["label"],
            "baseline_seconds": a["transport_seconds"],
            "candidate_seconds": b["transport_seconds"],
            "ratio": a["transport_seconds"] / b["transport_seconds"],
            "reduction_percent": 100 * (1 - b["transport_seconds"] / a["transport_seconds"]),
            "diagnostics": a["diagnostics"],
            "inserted_points": a["inserted_points"],
            "verified_digits": a["boundary"]["verified_digits"],
            "input_verified_digits": a["boundary"]["input_verified_digits"],
            "segment_coefficients_blake3": a["segment_coefficients_blake3"],
        }
        for a, b in zip(baseline["cases"], candidate["cases"], strict=True)
    ],
}
Path(sys.argv[3]).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
