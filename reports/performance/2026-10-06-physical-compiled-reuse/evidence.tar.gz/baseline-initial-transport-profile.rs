//! Single-core checked transport from the exported native starting boundaries.
use serde_json::{Value, json};
use std::{fs, time::Instant};
use symbolica::prelude::*;
use symbolica_amflow::gg_hg::{HiggsJetIntegralSystem, PluginFamilyKind};
use symbolica_amflow::transport_cache::{
    BoundaryAccuracy, CachedBoundary, CachedPoint, EpsilonRange, PointKind, RootSheet,
};
use symbolica_amflow::{
    ComplexFloat, Error, FlowOptions, Precision, Result, RunContext, RustFlowCache,
};

fn number(value: &Value) -> Result<Float> {
    let bits = value[2].as_u64().unwrap() as u32;
    let expression = Atom::parse(
        &format!(
            "({})/({})",
            value[0].as_str().unwrap(),
            value[1].as_str().unwrap()
        ),
        "initial_transport_profile",
        Default::default(),
    )
    .map_err(|error| Error::InvalidInput(error.to_string()))?;
    let rational = Complex::<Rational>::try_from(expression.as_view())
        .map_err(|error| Error::InvalidInput(error.to_string()))?;
    assert!(rational.im.is_zero());
    let result = Precision { bits }.rational(&rational.re).re;
    assert_eq!(result.to_rational(), rational.re);
    Ok(result)
}

fn encoded_number(value: &Float) -> Value {
    json!([value.to_rational().to_string(), value.prec()])
}

fn encoded_values(values: &[Vec<ComplexFloat>]) -> Value {
    json!(
        values
            .iter()
            .map(|row| row
                .iter()
                .map(|value| { json!([encoded_number(&value.re), encoded_number(&value.im)]) })
                .collect::<Vec<_>>())
            .collect::<Vec<_>>()
    )
}

fn boundary_evidence(boundary: &CachedBoundary) -> Result<Value> {
    Ok(json!({
        "coordinates": boundary.point.rounded_coordinates_as_exact()?.iter()
            .map(|(symbol, value)| (Atom::var(*symbol).to_canonical_string(), value.to_canonical_string()))
            .collect::<Vec<_>>(),
        "root_germ": boundary.point.root_germ().map(|germ| germ.sheets.iter()
            .map(|(symbol, sheet)| (Atom::var(*symbol).to_canonical_string(),
                if *sheet == RootSheet::Principal { 1 } else { -1 }))
            .collect::<Vec<_>>()),
        "leading": boundary.range.leading,
        "last": boundary.range.last,
        "coefficients": encoded_values(&boundary.coefficients),
        "comparison_errors": boundary.accuracy.comparison_errors().iter()
            .map(|row| row.iter().map(encoded_number).collect::<Vec<_>>()).collect::<Vec<_>>(),
        "verified_digits": boundary.accuracy.verified_digits(),
        "input_verified_digits": boundary.accuracy.input_verified_digits(),
        "working_bits": boundary.accuracy.working_bits(),
        "provenance": boundary.accuracy.provenance(),
    }))
}

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    let bytes = fs::read(&args[1])?;
    let document: Value =
        serde_json::from_slice(&bytes).map_err(|e| Error::InvalidInput(e.to_string()))?;
    assert_eq!(document["schema"], "higgs-jet-supplied-boundaries-v1");
    assert_eq!(
        document["encoding"],
        "exact-integer-ratio-with-binary-precision"
    );
    let options = FlowOptions {
        digits: 20,
        guard_digits: 60,
        series_order: 96,
        workers: 1,
        ..Default::default()
    };
    let mut cases = Vec::new();
    for kind in [PluginFamilyKind::Planar, PluginFamilyKind::Nonplanar] {
        let setup = Instant::now();
        let system = HiggsJetIntegralSystem::load(kind, "initial_transport_profile")?;
        let configuration = system
            .configurations("initial_transport_profile")?
            .into_iter()
            .find(|c| c.mass == "W" && c.permutation == 2)
            .unwrap();
        let input = document["boundaries"]
            .as_array()
            .unwrap()
            .iter()
            .find(|entry| entry["label"] == configuration.label)
            .unwrap();
        assert_eq!(
            input["dimension"].as_u64().unwrap() as usize,
            kind.dimension()
        );
        assert_eq!(input["leading_power"], 0);
        assert_eq!(input["verified_digits"], input["input_verified_digits"]);
        for (&coordinate, value) in system
            .basis_map()
            .coordinates
            .iter()
            .zip(input["coordinates"].as_array().unwrap())
        {
            let exact = Atom::parse(
                value.as_str().unwrap(),
                "initial_transport_profile",
                Default::default(),
            )
            .map_err(|e| Error::InvalidInput(e.to_string()))?;
            assert_eq!(exact, configuration.start[&coordinate]);
        }
        assert_eq!(
            input["root_sheets"].as_object().unwrap().len(),
            configuration.germ.sheets.len()
        );
        for (symbol, sheet) in &configuration.germ.sheets {
            let name = Atom::var(*symbol).to_canonical_string();
            let name = name.rsplit("::").next().unwrap();
            let sign = if *sheet == RootSheet::Principal {
                1
            } else {
                -1
            };
            assert_eq!(input["root_sheets"][name], sign);
        }
        let coefficients = input["coefficients"]
            .as_array()
            .unwrap()
            .iter()
            .map(|row| {
                row.as_array()
                    .unwrap()
                    .iter()
                    .map(|z| Ok(ComplexFloat::new(number(&z[0])?, number(&z[1])?)))
                    .collect::<Result<Vec<_>>>()
            })
            .collect::<Result<Vec<_>>>()?;
        let errors = input["comparison_errors"]
            .as_array()
            .unwrap()
            .iter()
            .map(|row| {
                row.as_array()
                    .unwrap()
                    .iter()
                    .map(number)
                    .collect::<Result<Vec<_>>>()
            })
            .collect::<Result<Vec<_>>>()?;
        let source = CachedBoundary {
            identity: system.transport().identity().clone(),
            point: CachedPoint::Exact(configuration.start.clone())
                .with_root_germ(configuration.germ.clone())?,
            kind: PointKind::Physical,
            range: EpsilonRange::new(0, coefficients.len() as i32 - 1)?,
            coefficients,
            accuracy: BoundaryAccuracy::supplied(
                input["verified_digits"].as_u64().unwrap() as u32,
                input["working_bits"].as_u64().unwrap() as u32,
                errors,
                &format!(
                    "{}; exact supplied export from native extension {}; original identity {}",
                    input["provenance"].as_str().unwrap(),
                    document["origin"]["native_extension_sha256"]
                        .as_str()
                        .unwrap(),
                    input["origin_identity"].as_str().unwrap()
                ),
            )?,
        };
        let mut cache = RustFlowCache::default();
        cache.insert(source)?;
        let setup_seconds = setup.elapsed().as_secs_f64();
        eprintln!("START {}", configuration.label);
        let started = Instant::now();
        let result = system.evaluate(
            &mut cache,
            &configuration.destination,
            &configuration.germ,
            4,
            &options,
            &RunContext::default(),
        )?;
        let transport_seconds = started.elapsed().as_secs_f64();
        let solution = result
            .transport
            .as_ref()
            .expect("initial target must require transport");
        assert_eq!(
            result.starting_point.rounded_coordinates_as_exact()?,
            configuration.start
        );
        assert!(solution.diagnostics.steps > 0);
        let segment_bytes = bincode::serde::encode_to_vec(
            &solution
                .segments
                .iter()
                .map(|segment| {
                    (
                        &segment.center,
                        &segment.end,
                        &segment.coefficients,
                        segment.working_bits,
                        segment.conditioning_digits,
                        format!("{:?}", segment.coordinate),
                    )
                })
                .collect::<Vec<_>>(),
            bincode::config::standard(),
        )
        .map_err(|e| Error::InvalidInput(e.to_string()))?;
        let output = json!({
            "label": configuration.label,
            "setup_seconds": setup_seconds,
            "transport_seconds": transport_seconds,
            "boundary": boundary_evidence(&result.boundary)?,
            "cache": cache.entries().iter().map(boundary_evidence).collect::<Result<Vec<_>>>()?,
            "inserted_points": result.inserted_points,
            "diagnostics": format!("{:?}", solution.diagnostics),
            "segment_coefficients_blake3": blake3::hash(&segment_bytes).to_hex().to_string(),
        });
        eprintln!("DONE {} {transport_seconds}", configuration.label);
        cases.push(output);
    }
    let report = json!({
        "scope": "single-core initial physical gg-hg transport from supplied native starting boundaries",
        "source_digest": env!("PORT_SOURCE_DIGEST"),
        "dependency_digest": env!("DEPENDENCY_SOURCE_DIGEST"),
        "rustred_runtime_arities": rustred::compiled_runtime_arities(),
        "input_blake3": blake3::hash(&bytes).to_hex().to_string(),
        "origin": document["origin"],
        "settings": {"digits": 20, "guard_digits": 60, "series_order": 96, "workers": 1},
        "cases": cases,
    });
    fs::write(
        &args[2],
        serde_json::to_vec_pretty(&report).map_err(|e| Error::InvalidInput(e.to_string()))?,
    )?;
    Ok(())
}
