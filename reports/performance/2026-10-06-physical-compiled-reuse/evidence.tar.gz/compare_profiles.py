"""Check two independently admitted profiles using exact rational arithmetic."""
import json
import sys
from fractions import Fraction
from pathlib import Path

high = json.loads(Path(sys.argv[1]).read_text())
low = json.loads(Path(sys.argv[2]).read_text())
for key in ("source_digest", "dependency_digest", "input_blake3", "origin", "rustred_runtime_arities"):
    assert high[key] == low[key], key
assert high["settings"]["digits"] == low["settings"]["digits"] == 20
assert high["settings"]["workers"] == low["settings"]["workers"] == 1

def rational(value):
    return Fraction(value[0])

def check_boundary(a, b):
    for key in ("coordinates", "root_germ", "leading", "last", "input_verified_digits", "provenance"):
        assert a[key] == b[key], key
    assert 20 <= a["verified_digits"] <= a["input_verified_digits"] <= 40
    assert 20 <= b["verified_digits"] <= b["input_verified_digits"] <= 40
    count = 0
    max_consistency_squared = Fraction(0)
    max_requested_squared = Fraction(0)
    max_error_requested_squared = Fraction(0)
    for va, vb, ea, eb in zip(a["coefficients"], b["coefficients"], a["comparison_errors"], b["comparison_errors"], strict=True):
        for za, zb, ax, bx in zip(va, vb, ea, eb, strict=True):
            ar, ai = map(rational, za)
            br, bi = map(rational, zb)
            ae, be = rational(ax), rational(bx)
            assert ae >= 0 and be >= 0
            delta_squared = (ar-br)**2 + (ai-bi)**2
            bound_squared = (ae+be)**2
            assert delta_squared <= bound_squared, "profiles exceed combined admitted errors"
            for r, i, error in [(ar, ai, ae), (br, bi, be)]:
                tolerance_squared = max(Fraction(1), r*r+i*i) / 10**40
                assert error*error <= tolerance_squared, "admitted error exceeds requested20 tolerance"
                assert delta_squared <= tolerance_squared, "profile difference exceeds requested20 tolerance"
                max_requested_squared = max(max_requested_squared, delta_squared/tolerance_squared)
                max_error_requested_squared = max(max_error_requested_squared, error*error/tolerance_squared)
            if bound_squared:
                max_consistency_squared = max(max_consistency_squared, delta_squared/bound_squared)
            count += 1
    return {
        "complex_coefficients_checked": count,
        "all_differences_within_combined_admitted_errors": True,
        "both_profiles_errors_and_differences_meet_requested20": True,
        "max_squared_difference_over_combined_bound": str(max_consistency_squared),
        "max_squared_difference_over_requested_tolerance": str(max_requested_squared),
        "max_squared_admitted_error_over_requested_tolerance": str(max_error_requested_squared),
    }

cases=[]
for a,b in zip(high["cases"],low["cases"],strict=True):
    assert a["label"] == b["label"]
    assert a["inserted_points"] == b["inserted_points"]
    assert a["cache"][0] == b["cache"][0], "supplied boundary changed"
    assert a["boundary"]["input_verified_digits"] == b["boundary"]["input_verified_digits"] == 40
    result=check_boundary(a["boundary"],b["boundary"])
    result["cached_boundaries"]=[check_boundary(x,y) for x,y in zip(a["cache"],b["cache"],strict=True)]
    result.update({
        "label":a["label"],
        "high_seconds":a["transport_seconds"],"low_seconds":b["transport_seconds"],
        "ratio":a["transport_seconds"]/b["transport_seconds"],
        "reduction_percent":100*(1-b["transport_seconds"]/a["transport_seconds"]),
        "high_diagnostics":a["diagnostics"],"low_diagnostics":b["diagnostics"],
        "high_verified_digits":a["boundary"]["verified_digits"],
        "low_verified_digits":b["boundary"]["verified_digits"],
        "input_verified_digits":b["boundary"]["input_verified_digits"],
    })
    cases.append(result)
report={"comparison":"exact rational cross-profile errors, requested accuracy and source/cache contracts", "high_settings":high["settings"],"low_settings":low["settings"],"cases":cases}
Path(sys.argv[3]).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({"cases":[{k:v for k,v in x.items() if not k.startswith('max_') and k!='cached_boundaries'} for x in cases]},indent=2))
